/**
 * @description 撤销 - 逆向操作，删除节点
 * @author fangzhicong
 */
import { Compile } from '../type';
export declare function revoke(data: Compile[]): void;
export declare function restore(data: Compile[]): void;
