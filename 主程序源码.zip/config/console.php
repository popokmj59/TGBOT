<?php
// +----------------------------------------------------------------------
// | 控制台配置
// +----------------------------------------------------------------------
return [
    // 指令定义
    'commands' => [
		'csv' => 'app\api\command\Csv',
        'monitor:trc' => 'app\command\MonitorTrc',
        'tg:consume' => 'app\command\TgQueueConsumer',
    ],
];
