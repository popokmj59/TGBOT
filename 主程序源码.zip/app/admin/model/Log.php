<?php 
/*
 module:		日志管理控制器
 create_time:	2022-02-25 17:10:33
 author:		
 contact:		
*/

namespace app\admin\model;
use think\Model;

class Log extends Model {


	protected $connection = 'mysql';

 	protected $pk = 'id';

 	protected $name = 'log';




}

