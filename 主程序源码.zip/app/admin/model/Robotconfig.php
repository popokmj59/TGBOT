<?php 
/*
 module:		机器人设置控制器
 create_time:	2022-03-11 19:32:50
 author:		
 contact:		
*/

namespace app\admin\model;
use think\Model;

class Robotconfig extends Model {


	protected $connection = 'mysql';

 	protected $pk = 'robotconfig_id';

 	protected $name = 'robotconfig';




}

