<?php 
/*
 module:		缩略图配置控制器
 create_time:	2021-12-06 23:37:36
 author:		
 contact:		
*/

namespace app\admin\model;
use think\Model;

class Uploadconfig extends Model {


	protected $connection = 'mysql';

 	protected $pk = 'id';

 	protected $name = 'upload_config';




}

