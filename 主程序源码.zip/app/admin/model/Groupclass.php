<?php 
/*
 module:		群分类控制器
 create_time:	2022-03-11 16:43:09
 author:		
 contact:		
*/

namespace app\admin\model;
use think\Model;

class Groupclass extends Model {


	protected $connection = 'mysql';

 	protected $pk = 'id';

 	protected $name = 'groupclass';




}

