<?php 
namespace app\admin\model;
use think\Model;

class Files extends Model {


	protected $connection = 'mysql';

 	protected $pk = 'id';

 	protected $name = 'file';




}

