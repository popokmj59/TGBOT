<?php 
/*
 module:		群列表控制器
 create_time:	2022-03-11 16:39:30
 author:		
 contact:		
*/

namespace app\admin\model;
use think\Model;

class Group extends Model {


	protected $connection = 'mysql';

 	protected $pk = 'id';

 	protected $name = 'group';




}

