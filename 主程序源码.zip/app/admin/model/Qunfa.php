<?php 
/*
 module:		群发公告控制器
 create_time:	2022-03-11 17:21:18
 author:		
 contact:		
*/

namespace app\admin\model;
use think\Model;

class Qunfa extends Model {


	protected $connection = 'mysql';

 	protected $pk = 'id';

 	protected $name = 'qunfa';




}

