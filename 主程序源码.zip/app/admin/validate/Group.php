<?php 
/*
 module:		群列表控制器
 create_time:	2022-03-11 16:39:30
 author:		
 contact:		
*/

namespace app\admin\validate;
use think\validate;

class Group extends validate {


	protected $rule = [
	];

	protected $message = [
	];

	protected $scene  = [
		'add'=>[''],
		'update'=>[''],
	];



}

