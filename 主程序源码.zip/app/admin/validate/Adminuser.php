<?php 
/*
 module:		用户管理控制器
 create_time:	2022-02-25 17:10:29
 author:		
 contact:		
*/

namespace app\admin\validate;
use think\validate;

class Adminuser extends validate {


	protected $rule = [
	];

	protected $message = [
	];

	protected $scene  = [
		'add'=>[''],
		'update'=>[''],
	];



}

