<?php 
/*
 module:		群发公告控制器
 create_time:	2022-03-11 17:21:18
 author:		
 contact:		
*/

namespace app\admin\validate;
use think\validate;

class Qunfa extends validate {


	protected $rule = [
	];

	protected $message = [
	];

	protected $scene  = [
		'index'=>[''],
	];



}

