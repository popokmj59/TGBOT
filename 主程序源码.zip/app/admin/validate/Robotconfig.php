<?php 
/*
 module:		机器人设置控制器
 create_time:	2022-03-11 19:32:50
 author:		
 contact:		
*/

namespace app\admin\validate;
use think\validate;

class Robotconfig extends validate {


	protected $rule = [
	];

	protected $message = [
	];

	protected $scene  = [
		'index'=>[''],
	];



}

