<?php 
/*
 module:		日志管理控制器
 create_time:	2022-02-25 17:10:33
 author:		
 contact:		
*/

namespace app\admin\validate;
use think\validate;

class Log extends validate {


	protected $rule = [
	];

	protected $message = [
	];

	protected $scene  = [
	];



}

