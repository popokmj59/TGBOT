<?php 
/*
 module:		用户列表控制器
 create_time:	2022-03-12 12:53:52
 author:		
 contact:		
*/

namespace app\admin\validate;
use think\validate;

class User extends validate {


	protected $rule = [
	];

	protected $message = [
	];

	protected $scene  = [
		'add'=>[''],
		'update'=>[''],
	];



}

