<?php 
/*
 module:		基本配置控制器
 create_time:	2022-02-25 17:26:30
 author:		
 contact:		
*/

namespace app\admin\validate;
use think\validate;

class Baseconfig extends validate {


	protected $rule = [
	];

	protected $message = [
	];

	protected $scene  = [
		'index'=>[''],
	];



}

