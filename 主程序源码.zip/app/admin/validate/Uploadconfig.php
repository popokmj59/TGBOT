<?php 
/*
 module:		缩略图配置控制器
 create_time:	2021-12-06 23:37:36
 author:		
 contact:		
*/

namespace app\admin\validate;
use think\validate;

class Uploadconfig extends validate {


	protected $rule = [
	];

	protected $message = [
	];

	protected $scene  = [
		'add'=>[''],
		'update'=>[''],
	];



}

