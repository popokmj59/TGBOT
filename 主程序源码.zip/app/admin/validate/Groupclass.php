<?php 
/*
 module:		群分类控制器
 create_time:	2022-03-11 16:43:09
 author:		
 contact:		
*/

namespace app\admin\validate;
use think\validate;

class Groupclass extends validate {


	protected $rule = [
	];

	protected $message = [
	];

	protected $scene  = [
		'add'=>[''],
		'update'=>[''],
	];



}

