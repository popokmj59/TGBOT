<?php
namespace app\admin\controller;
use think\facade\Db;


class Index extends Admin {
	
	
	public function index(){
		return view('index');
	}
	
	
	//后台首页主体内容
	public function main(){
		if(!$this->request->isPost()){
			return view('main');
		}else{		
			//折线图数据
			$echat_data['day_count'] = [
				'title'=>'当月业绩折线图',
				'day'=>[1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30],	//每月天数
				'data'=>[0,0,0,0,0,126,246,452,45,36,479,588,434,9,18,27,18,88,45,0,0,0,0,0,0,0,0,0,0,0]	//每天数据
			];
			
			if(config('my.show_home_chats',true)){
				$data['echat_data'] = $echat_data;
			}
			$data['card_data'] = $this->getCardData();
			$data['menus'] = $this->getMenuLink();
			$data['status'] = 200;
			return json($data);
		}
	}
	
	
	//头部提示消息
	function getNotice(){
		$data = [
			[
				'num'=>5,
				'title'=>'条评论待回复',
				'url'=>(string)url('admin/Membe/index'),
			],
			[
				'num'=>12,
				'title'=>'条订单待处理',
				'url'=>(string)url('admin/Map/index'),
			],
			[
				'num'=>50,
				'title'=>'条私信待处理',
				'url'=>(string)url('admin/Membe/index'),
			],
		];
		
		return json(['status'=>200,'data'=>$data]);
	}
	
	//首页统计数据
	private function getCardData(){
		// 定义截止时间：今天的 07:00
		$now = time();
		$today7am = strtotime(date('Y-m-d 07:00:00'));
		
		if ($now < $today7am) {
			// 如果还没到今天早上7点，那么“今天”的业务周期是从昨天早上7点到今天早上7点
			$start = strtotime(date('Y-m-d 07:00:00', strtotime('-1 day')));
			$end = $today7am;
		} else {
			// 如果已经过了今天早上7点，那么“今天”的业务周期是从今天早上7点到明天早上7点
			// 但这里是“截止凌晨07:00”，通常指昨天7点到今天7点的数据？
			// 或者是“今天截至目前”？用户说“截止凌晨07:00的统计...今天的所有群的一个总入款”
			// 如果是“今天”的数据，且统一按7点日切。
			// 那么如果是下午15点，数据应该是今天07:00到15:00？
			// 用户说“都每天统计到凌晨7点”，可能意思是日切点是7点。
			// 假设现在是 27号 18:00。日切是7点。那么今天是 27号07:00 - 28号07:00。
			// 统计范围应该是 start = 27号07:00, end = 28号07:00 (或者 now)
			$start = $today7am;
			$end = strtotime(date('Y-m-d 07:00:00', strtotime('+1 day')));
		}

		// 总入款 (RMB)
		$totalIncome = Db::name('order')
			->where('rltime', '>=', $start)
			->where('rltime', '<', $end)
			->where('amount', '>', 0)
			->sum('amount');

		// 总下发U数 (USDT绝对值)
		// 下发金额在数据库是负数，usdt也是负数（如果正确记录的话）
		// 我们取绝对值
		$totalOutcomeUsdt = Db::name('order')
			->where('rltime', '>=', $start)
			->where('rltime', '<', $end)
			->where('amount', '<', 0)
			->sum('usdt');
		$totalOutcomeUsdt = abs($totalOutcomeUsdt);

		// 总未下发U数 (总入款U - 总下发U)
		// 方法1：直接 sum('usdt')。 因为下发是负数，相加即为余额。
		// 方法2：分别统计入款U 和 下发U。
		// 考虑到可能存在 usdt 字段为 0 的旧数据，最好有一致性。
		// 但 Tg.php 写入时已经尝试计算 usdt。
		// 这里简化处理，直接 sum('usdt')。
		$netUsdt = Db::name('order')
			->where('rltime', '>=', $start)
			->where('rltime', '<', $end)
			->sum('usdt');
		// 修正：如果 usdt 字段对于某些入款是 0 (旧数据)，那么 netUsdt 会偏小。
		// 但用户之前已经要求加字段并录入，假设新数据是准的。
		// 显示保留2位小数
		$totalOutcomeUsdt = round($totalOutcomeUsdt, 2);
		$netUsdt = round($netUsdt, 2);

		$card_data = [	//头部统计数据
			[
			  'title_icon'=>"el-icon-s-data",
			  'card_title'=> "今日总入款 (RMB)",
			  'card_cycle'=> "截止 07:00",
			  'vist_num'=> $totalIncome,
			  'vist_all_icon'=> "el-icon-trophy",
			],
			[
			  'title_icon'=>"el-icon-money",
			  'card_title'=> "今日总下发 (U)",
			  'card_cycle'=> "截止 07:00",
			  'vist_num'=> $totalOutcomeUsdt,
			  'vist_all_icon'=> "el-icon-trophy",
			],
			[
			  'title_icon'=>"el-icon-wallet",
			  'card_title'=> "今日未下发 (U)",
			  'card_cycle'=> "截止 07:00",
			  'vist_num'=> $netUsdt,
			  'vist_all_icon'=> "el-icon-trophy",
			],
		];
		
		return $card_data;
	}
	
	
	//获取首页快捷导航
	private function getMenuLink(){
		if(config('my.show_home_menu',true)){
			$data = Db::name('menu')->field('title,menu_pic,controller_name,url')->where('app_id',1)->where('home_show',1)->limit(8)->select()->toArray();
			foreach($data as $k=>$v){
				if(!$v['url']){
					$data[$k]['url'] = (string)url('admin/'.str_replace('/','.',$v['controller_name']).'/index');
				}else{
					$data[$k]['url'] = $v['url'];
				}
			}
			return $data;
		}
	}
	
	
	
}