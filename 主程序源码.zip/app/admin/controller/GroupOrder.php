<?php 
namespace app\admin\controller;
use app\admin\model\Order as OrderModel;
use app\admin\model\Group as GroupModel;
use think\facade\Db;

class GroupOrder extends Admin {

	/*
 	* @Description  群账单统计列表
 	*/
	function index(){
		if (!$this->request->isPost()){
			return view('index');
		}else{
			$limit  = $this->request->post('limit', 20, 'intval');
			$page = $this->request->post('page', 1, 'intval');

			// 1. 获取所有群组
			$groupModel = new GroupModel();
            // 如果有搜索条件
            $whereGroup = [];
            $name = $this->request->post('name', '', 'serach_in');
            $tg_groupid = $this->request->post('tg_groupid', '', 'serach_in');
            
            if ($name) $whereGroup[] = ['name', 'like', "%{$name}%"];
            if ($tg_groupid) $whereGroup[] = ['tg_groupid', 'like', "%{$tg_groupid}%"];

            $total = $groupModel->where($whereGroup)->count();
            $groups = $groupModel->where($whereGroup)
                ->order('id desc')
                ->paginate(['list_rows'=>$limit, 'page'=>$page])
                ->toArray();
            
            $list = $groups['data'];
            
            // 2. 遍历群组计算统计数据
            foreach ($list as &$group) {
                $gid = $group['tg_groupid'];
                
                // 获取该群的日切时间
                $cutoffTime = !empty($group['cutoff_time']) ? $group['cutoff_time'] : '05:00';
                
                // 计算今日业务周期的起止时间
                $now = time();
                $todayCutoff = strtotime(date('Y-m-d ' . $cutoffTime . ':00'));
                
                if ($now < $todayCutoff) {
                    $startTime = strtotime(date('Y-m-d ' . $cutoffTime . ':00', strtotime('-1 day')));
                    $endTime = $todayCutoff;
                } else {
                    $startTime = $todayCutoff;
                    $endTime = strtotime(date('Y-m-d ' . $cutoffTime . ':00', strtotime('+1 day')));
                }
                
                // 查询今日入款 (zd!=2 排除开始标记, amount>0)
                $todayIncome = Db::name('order')
                    ->where('group_id', $gid)
                    ->where('rltime', '>=', $startTime)
                    ->where('rltime', '<', $endTime)
                    ->where('amount', '>', 0)
                    ->where('zd', '<>', 2)
                    ->sum('amount');
                    
                $todayIncomeUsdt = Db::name('order')
                    ->where('group_id', $gid)
                    ->where('rltime', '>=', $startTime)
                    ->where('rltime', '<', $endTime)
                    ->where('amount', '>', 0)
                    ->where('zd', '<>', 2)
                    ->sum('usdt');

                // 查询今日下发 (amount<0)
                $todayOutcome = Db::name('order')
                    ->where('group_id', $gid)
                    ->where('rltime', '>=', $startTime)
                    ->where('rltime', '<', $endTime)
                    ->where('amount', '<', 0)
                    ->where('zd', '<>', 2)
                    ->sum('amount'); // 负数
                
                $todayOutcomeUsdt = Db::name('order')
                    ->where('group_id', $gid)
                    ->where('rltime', '>=', $startTime)
                    ->where('rltime', '<', $endTime)
                    ->where('amount', '<', 0)
                    ->where('zd', '<>', 2)
                    ->sum('usdt'); // 正数 (usdt字段存的是绝对值还是负数？看Tg.php逻辑)
                
                // 检查Tg.php逻辑：
                // $finalUsdt = ($is_outcome) ? -1 * abs($calculatedUsdt) : abs($calculatedUsdt);
                // 所以 usdt 也是带符号的。
                
                // 今日未回款 (U) = 今日入款U - 今日下发U (下发是负数，所以是 入款 + 下发)
                // Wait, logic check:
                // Income: +100U
                // Outcome: -80U
                // Remaining: 20U
                // Sum(usdt) = 100 + (-80) = 20. Correct.
                $todayRemainingUsdt = $todayIncomeUsdt + $todayOutcomeUsdt;

                // 总入款 (历史所有)
                $totalIncome = Db::name('order')
                    ->where('group_id', $gid)
                    ->where('amount', '>', 0)
                    ->where('zd', '<>', 2)
                    ->sum('amount');
                    
                $totalIncomeUsdt = Db::name('order')
                    ->where('group_id', $gid)
                    ->where('amount', '>', 0)
                    ->where('zd', '<>', 2)
                    ->sum('usdt');

                // 格式化数据
                $group['today_income'] = number_format($todayIncome, 2);
                $group['today_income_u'] = number_format($todayIncomeUsdt, 2);
                
                $group['today_outcome'] = number_format(abs($todayOutcome), 2); // 显示绝对值方便阅读
                $group['today_outcome_u'] = number_format(abs($todayOutcomeUsdt), 2);
                
                $group['today_remaining_u'] = number_format($todayRemainingUsdt, 2);
                
                $group['total_income'] = number_format($totalIncome, 2);
                $group['total_income_u'] = number_format($totalIncomeUsdt, 2);
            }

			$data['status'] = 200;
			$data['data'] = ['data' => $list, 'total' => $total];
			return json($data);
		}
	}
}

