<?php
namespace app\admin\controller\Sys\model;

use think\Model;

class Application extends Model
{
	
	protected $pk = 'app_id';
	
	
	
}