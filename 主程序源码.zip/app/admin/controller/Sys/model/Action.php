<?php
namespace app\admin\controller\Sys\model;

use think\Model;

class Action extends Model
{
	
	protected $pk = 'id';
	
	
}