<?php 
namespace app\index\controller;
use think\facade\Db;
use think\facade\View;
use think\facade\Request;

class Order{
    public function jr(){
        return $this->renderBill(false);
    }

    public function zr(){
        return $this->renderBill(true);
    }

    private function renderBill($isYesterday){
        $groupid = request()->param('groupid');
        $dateParam = request()->param('date');
        $export = request()->param('export');

        // 1. Determine Time Range (Day Cutoff: dynamic from group settings or default 05:00)
        $group = Db::name('group')->where('tg_groupid', $groupid)->find();
        $cutoffTime = ($group && !empty($group['cutoff_time'])) ? $group['cutoff_time'] : '05:00';
        // Normalize time format to ensure it works
        $cutoffTime = date('H:i', strtotime($cutoffTime));
        
        $now = time();
        $todayCutoff = strtotime(date('Y-m-d ' . $cutoffTime . ':00'));
        
        if ($dateParam) {
            // User selected a specific date
            $reportDate = $dateParam;
            $start = strtotime($reportDate . ' ' . $cutoffTime . ':00');
            $end = $start + 86400; // Next day same time
        } else {
            // Default logic
            if ($isYesterday) {
                // Yesterday
                if ($now < $todayCutoff) {
                    $start = strtotime(date('Y-m-d ' . $cutoffTime . ':00', strtotime('-2 day')));
                    $end = strtotime(date('Y-m-d ' . $cutoffTime . ':00', strtotime('-1 day')));
                    $reportDate = date('Y-m-d', strtotime('-2 day'));
                } else {
                    $start = strtotime(date('Y-m-d ' . $cutoffTime . ':00', strtotime('-1 day')));
                    $end = $todayCutoff;
                    $reportDate = date('Y-m-d', strtotime('-1 day'));
                }
            } else {
                // Today
                if ($now < $todayCutoff) {
                    $start = strtotime(date('Y-m-d ' . $cutoffTime . ':00', strtotime('-1 day')));
                    $end = $todayCutoff;
                    $reportDate = date('Y-m-d', strtotime('-1 day'));
                } else {
                    $start = $todayCutoff;
                    $end = strtotime(date('Y-m-d ' . $cutoffTime . ':00', strtotime('+1 day')));
                    $reportDate = date('Y-m-d');
                }
            }
        }

        // 2. Fetch Data
        $orders = Db::name('order')
            ->where('group_id', $groupid)
            ->where('rltime', '>=', $start)
            ->where('rltime', '<', $end)
            ->order('rltime', 'desc')
            ->select();

        $groupName = $group ? $group['name'] : 'Unknown Group';
        $baseRateConfig = Db::name('base_config')->where('name', 'rate')->find();
        $baseRate = $baseRateConfig ? $baseRateConfig['data'] : 12.8;

        // 3. Process Data
        $incomeList = []; // 入款明细
        $outcomeList = []; // 下发明细
        
        // Payer Stats (入款分类: Group by Payer)
        // Format: Name => [income=>0, incomeUsdt=>0, outcome=>0, outcomeUsdt=>0, count=>0]
        $payerStats = [];

        // Rate Stats (汇率分类: Group by Rate)
        // Format: Rate => [totalRmb=>0, totalUsdt=>0]
        $rateStats = [];

        // Operator Stats (入款分组: Group by Operator, Income only)
        // Format: Operator => [amount=>0, usdt=>0, count=>0]
        $operatorStats = [];

        // Totals
        $totalIncome = 0;
        $totalIncomeUsdt = 0;
        $totalOutcome = 0;
        $totalOutcomeUsdt = 0;
        
        foreach ($orders as $order) {
            $amount = floatval($order['amount']);
            
            // Skip 0 amounts (Start markers, etc.)
            if ($amount == 0) continue;

            // Fallback for usdt if missing (compatibility with old records)
            $usdt = isset($order['usdt']) && $order['usdt'] != 0 ? floatval($order['usdt']) : 0;
            // Fallback for operator_name
            $operator = isset($order['operator_name']) && !empty($order['operator_name']) ? $order['operator_name'] : '-';
            
            // Calculate Rate if needed (Amount / USDT)
            $impliedRate = ($usdt != 0) ? round(abs($amount) / abs($usdt), 2) : $baseRate;
            
            // Fix USDT calculation for old records if 0
            if ($usdt == 0 && $amount != 0) {
                 $usdt = round($amount / $baseRate, 3);
                 $impliedRate = $baseRate;
            }

            $order['usdt'] = $usdt;
            $order['rate'] = $impliedRate;
            $order['operator'] = $operator;

            $tgname = $order['tgname'] ?: '未知';
            if ($tgname === '0') {
                $tgname = ($amount > 0) ? '直充' : '直下';
            }

            if ($amount > 0) {
                // INCOME
                $incomeList[] = $order;
                $totalIncome += $amount;
                $totalIncomeUsdt += $usdt;

                // Payer Stats
                if (!isset($payerStats[$tgname])) {
                    $payerStats[$tgname] = ['income'=>0, 'incomeUsdt'=>0, 'outcome'=>0, 'outcomeUsdt'=>0, 'count'=>0];
                }
                $payerStats[$tgname]['income'] += $amount;
                $payerStats[$tgname]['incomeUsdt'] += $usdt;
                $payerStats[$tgname]['count']++;

                // Rate Stats
                $rateKey = (string)$impliedRate;
                if (!isset($rateStats[$rateKey])) {
                    $rateStats[$rateKey] = ['totalRmb'=>0, 'totalUsdt'=>0];
                }
                $rateStats[$rateKey]['totalRmb'] += $amount;
                $rateStats[$rateKey]['totalUsdt'] += $usdt;

                // Operator Stats
                if (!isset($operatorStats[$operator])) {
                    $operatorStats[$operator] = ['amount'=>0, 'usdt'=>0, 'count'=>0];
                }
                $operatorStats[$operator]['amount'] += $amount;
                $operatorStats[$operator]['usdt'] += $usdt;
                $operatorStats[$operator]['count']++;

            } elseif ($amount < 0) {
                // OUTCOME (Negative Amount)
                $outcomeList[] = $order;
                $absAmount = abs($amount);
                $absUsdt = abs($usdt);
                
                $totalOutcome += $absAmount;
                $totalOutcomeUsdt += $absUsdt;

                // Payer Stats (Track outcome for this user)
                if (!isset($payerStats[$tgname])) {
                    $payerStats[$tgname] = ['income'=>0, 'incomeUsdt'=>0, 'outcome'=>0, 'outcomeUsdt'=>0, 'count'=>0];
                }
                $payerStats[$tgname]['outcome'] += $absAmount;
                $payerStats[$tgname]['outcomeUsdt'] += $absUsdt;
                // Note: Outcome usually doesn't count towards "Income Count" or Operator Income Stats
            }
        }

        // CSV Export Logic
        if ($export == '1') {
             // Implementation of simple CSV export
             $filename = $groupName . '-' . $reportDate . '.csv';
             header('Content-Type: text/csv');
             header('Content-Disposition: attachment;filename="'.$filename.'"');
             $fp = fopen('php://output', 'w');
             // UTF-8 BOM
             fwrite($fp, chr(0xEF).chr(0xBB).chr(0xBF));
             
             fputcsv($fp, ['入款明细']);
             fputcsv($fp, ['入款人', '操作人', '金额', '汇率', 'USDT', '时间']);
             foreach ($incomeList as $v) {
                 fputcsv($fp, [$v['tgname'], $v['operator'], $v['amount'], $v['rate'], $v['usdt'], date('Y-m-d H:i:s', $v['rltime'])]);
             }
             fputcsv($fp, []);
             fputcsv($fp, ['下发明细']);
             fputcsv($fp, ['收款人', '金额', '汇率', 'USDT', '时间']);
             foreach ($outcomeList as $v) {
                 fputcsv($fp, [$v['tgname'], abs($v['amount']), $v['rate'], abs($v['usdt']), date('Y-m-d H:i:s', $v['rltime'])]);
             }
             fclose($fp);
             exit;
        }

        // View Assign
        View::assign([
            'groupName' => $groupName,
            'baseRate' => $baseRate,
            'reportDate' => $reportDate,
            'groupid' => $groupid,
            
            'incomeList' => $incomeList,
            'outcomeList' => $outcomeList,
            
            'payerStats' => $payerStats,
            'rateStats' => $rateStats,
            'operatorStats' => $operatorStats,
            
            'totalIncome' => $totalIncome,
            'totalIncomeUsdt' => $totalIncomeUsdt,
            'totalOutcome' => $totalOutcome,
            'totalOutcomeUsdt' => $totalOutcomeUsdt,
            
            'remainingRmb' => $totalIncome - $totalOutcome,
            'remainingUsdt' => $totalIncomeUsdt - $totalOutcomeUsdt,
        ]);

        return view('jr');
    }
}
