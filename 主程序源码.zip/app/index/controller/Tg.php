<?php 

namespace app\index\controller;
use think\facade\Db;
use think\facade\Log;


class Tg{
    //初始化tg机器人
    public function set(){
        $params = request()->param();
        $token=$params['token'];
        //查询域名
        $seturl=Db::name('base_config')->where('name','domain')->find();
        if (!$seturl || !isset($seturl['data'])) {
             return json(['status'=>-1, 'msg'=>'请先在后台配置域名']);
        }
        $hdurl=$seturl['data'].'/index/tg/message';
        $url="https://api.telegram.org/bot".$token."/setWebhook?url=".$hdurl;
        $data=get_http($url);
        // var_dump($data);
        if($data['ok']){
            $datas['status']=200;
        }else {
            $datas['status']=-1;
        }
		return $datas;
	}
    // 获取本群日切时间
    private function getGroupCutoff($groupid) {
        $group = Db::name('group')->where('tg_groupid', $groupid)->find();
        if ($group && !empty($group['cutoff_time'])) {
            // 确保格式为 HH:mm
            return date('H:i', strtotime($group['cutoff_time']));
        }
        return '05:00';
    }

    // 权限检查 (支持全局管理员和本群操作人)
    private function checkAuth($uid, $username, $groupid) {
        // 1. 获取全局管理员
        $glid = Db::name('robotconfig')->where('name', 'gl')->find();
        $globalAdmins = $glid ? array_map('trim', explode(",", $glid['data'])) : [];

        // 2. 获取本群操作人
        $group = Db::name('group')->where('tg_groupid', $groupid)->find();
        $groupOps = [];
        if ($group && !empty($group['operators'])) {
            $groupOps = array_map('trim', explode(",", $group['operators']));
        }

        // 3. 检查是否在任一列表中
        return in_array($username, $globalAdmins) || in_array($uid, $globalAdmins) ||
               in_array($username, $groupOps) || in_array($uid, $groupOps);
    }

	/**
	 * tg接收消息 (Producer)
	 * 接收到 webhook 消息后，直接推入 Redis 队列，快速返回 200 OK
	 */
	public function message()
	{
	    $params = request()->param();
        // 快速返回 200 (ThinkPHP 无法直接中途断开连接，除非使用 fastcgi_finish_request，但入队很快)
        
        if (empty($params['message'])) {
            return 'true';
        }
        
        // 简单校验
        $message_id = empty($params['message']['message_id']) ? '' : $params['message']['message_id'];
        $user_id = empty($params['message']['from']['id']) ? '' : $params['message']['from']['id'];
        if ($user_id == '') {
            return 'true';
        }

        // 推入 Redis 队列
        try {
            // 使用原生 Redis (TP Cache Redis Store)
            $redis = \think\facade\Cache::store('redis')->handler();
            // 队列名: tg_message_queue
            // 将整个 params 推入
            $redis->rPush('tg_message_queue', json_encode($params));
            
        } catch (\Throwable $e) {
            \think\facade\Log::error("Redis Push Error: " . $e->getMessage());
            // 如果 Redis 挂了，降级为同步处理 (为了不丢消息)
            $this->processMessageFromArray($params);
        }

        return 'true';
    }

    /**
     * 实际处理消息逻辑 (Consumer 调用)
     * 将原来的 message() 逻辑搬到这里，改名为 processMessageFromArray
     * @param array $params
     */
    public function processMessageFromArray($params) 
    {
	    //判断是否有消息
	    if(empty($params['message'])){
	       return 'true';
	    }
	    //消息id
	    $message_id=empty($params['message']['message_id']) ? '' :$params['message']['message_id'];
	    $user_id = empty($params['message']['from']['id']) ? '' : $params['message']['from']['id'];
	    if($user_id==''){
	        return 'true';
	    }
        $firstName = isset($params['message']['from']['first_name']) ? $params['message']['from']['first_name'] : '';
        $lastName = isset($params['message']['from']['last_name']) ? $params['message']['from']['last_name'] : '';
	    $user_name = $firstName . $lastName;
        if (empty($user_name) && isset($params['message']['from']['username'])) {
            $user_name = $params['message']['from']['username'];
        }
	    //判断群
		//群
	    if($params['message']['chat']['type']=='group'||$params['message']['chat']['type']=='supergroup'){
	        $groupid=$params['message']['chat']['id'];//群id
	        $grouptitle=$params['message']['chat']['title'];//群标题
	        $type='group';
	        //判断是不是新成员
	        $xin = empty($params['message']['new_chat_member']) ? '':$params['message']['new_chat_member'];
	        if($xin!=''){
	            //查询欢迎语
	            $hyy=Db::name('robotconfig')->where('name','hy')->find();
	            $msg='@'.$params['message']['new_chat_member']['username']."\n".$hyy['data'];
                sendText($groupid,$msg);
	           return 'true';
	        }else{
	           $xin=false; 
	        }
	   //一对一
	    }else{
	        $type='ydy';
	        $groupid=$params['message']['chat']['id'];//用户id
	    }
	    //判断消息类型
	    if(!empty($params["message"]["text"])){
	        $msgtype='text';
	        $msg=$params["message"]["text"];
	    }elseif (!empty($params["message"]["photo"])) {
	        $msgtype='photo';
	        $msg=$params["message"]["photo"][0]['file_id'];
	    }else{
	        $msgtype='no';
	    }
	    if($msgtype!='no'){
            // 【黑科技】缓存所有群消息，用于解决机器人回复不显示引用的问题
            // Key: tg_msg:{group_id}:{message_id}
            // Value: 消息内容
            if ($type == 'group' && !empty($msg)) {
                $cacheKey = "tg_msg:{$groupid}:{$message_id}";
                // 缓存 24 小时
                \think\facade\Cache::store('redis')->set($cacheKey, $msg, 86400);
            }

            // 计算器功能 (任何人可用)
            // 支持 +, -, *, / 以及混合运算，如 1000-14/12.5
            // 排除如果是命令格式（如 +100 是记账，不应该被计算器拦截，但纯数学表达式如 100+200 应该被计算）
            
            $cleanMsg = str_replace(' ', '', $msg);
            // 允许的字符：数字, 小数点, +, -, *, /
            // 且必须包含至少一个运算符
            if (preg_match('/^[\d\.\+\-\*\/]+$/', $cleanMsg) && preg_match('/[\+\-\*\/]/', $cleanMsg)) {
                $isAccounting = false;
                
                // 排除记账格式：
                // +金额
                // -金额
                // +金额/汇率
                // -金额/汇率
                // 下发... (already handled by groupgl text check, but here we check msg content)
                
                // 记账特征：以 + 或 - 开头
                if (preg_match('/^[\+\-]/', $cleanMsg)) {
                    
                    // 记账格式 +A, -A, +A/B, -A/B
                    // 计算器格式 +A+B, +A-B, +A*B
                    
                    // 简单判断：如果以 +/- 开头，且后续没有其他 + - *
                    // 注意 / 可能用于记账 (rate) 也可能用于除法
                    
                    // 如果是记账命令，通常只有一个 +/- 在开头，或者有一个 / 在中间
                    // 如果有多个运算符，或者是 *，通常是计算器
                    
                    // 统计运算符数量
                    $opCount = preg_match_all('/[\+\-\*\/]/', $cleanMsg);
                    
                    // 如果是 +100 (1个op) -> 记账
                    // +100/10 (2个op) -> 记账
                    // +100+10 (2个op) -> 计算
                    // 100+10 (1个op, 不以+/-开头) -> 计算
                    
                    if (strpos($cleanMsg, '*') !== false) {
                        $isAccounting = false; // 包含乘法肯定是计算器
                    } elseif ($opCount == 1) {
                         // 只有开头的一个 +/-
                         $isAccounting = true; 
                    } elseif ($opCount == 2) {
                        // 开头有一个 +/-，中间还有一个
                        // 如果中间是 /，可能是记账 (+100/10)
                        if (preg_match('/^[\+\-]\d+(\.\d+)?\/\d+(\.\d+)?$/', $cleanMsg)) {
                             $isAccounting = true;
                        } else {
                             // 例如 +100+10, +100-10
                             $isAccounting = false;
                        }
                    } else {
                        // 超过2个运算符，肯定是复杂计算
                        $isAccounting = false;
                    }
                }
                
                if (!$isAccounting) {
                    try {
                        // 防止除以零
                        if (preg_match('/\/0(\.0+)?(?![1-9])/', $cleanMsg)) {
                             // 除以0，忽略
                        } else {
                            $result = eval("return $cleanMsg;");
                            
                            // 格式化结果
                            if (floor($result) == $result) {
                                $showResult = (int)$result;
                            } else {
                                $showResult = round($result, 4);
                            }
                            
                            // 私聊直接回复结果，群聊回复 算式=结果
                            if ($type == 'ydy') {
                                $reply = "{$showResult}";
                            } else {
                                $reply = "{$cleanMsg} = {$showResult}";
                            }
                            
                            huiText($message_id, $groupid, $reply);
                            return 'true';
                        }
                    } catch (\Throwable $e) {
                        // 计算错误，忽略
                    }
                }
            }

            // 【跨群监听转发】
            // 检查当前群是否在监听列表
            $isSourceGroup = \think\facade\Cache::store('redis')->sIsMember('monitor_source_groups', $groupid);
            if ($isSourceGroup && $type == 'group') {
                // 检查是否包含地址信息 (复用 V5.0 核心逻辑)
                $geoKeywords = '省|市|区|县|镇|乡|村|街道|路|号|大厦|苑|小区|酒店|学校|大学|中学|小学|广场|中心|公园|州|盟|旗|站|机场|道|北京|天津|上海|重庆|河北|山西|辽宁|吉林|黑龙江|江苏|浙江|安徽|福建|江西|山东|河南|湖北|湖南|广东|海南|四川|贵州|云南|陕西|甘肃|青海|内蒙古|广西|西藏|宁夏|新疆|香港|澳门|南宁|广州|深圳|东莞|佛山|中山|珠海|惠州|江门|肇庆';
                
                // 只有当消息包含地理关键词时才转发
                if (preg_match("/({$geoKeywords})/u", $msg)) {
                    // 获取目标群ID
                    $targetGroupId = \think\facade\Cache::store('redis')->get('monitor_target_group');
                    
                    if ($targetGroupId && $targetGroupId != $groupid) {
                        // 转发消息内容
                        // 格式：收到新单 (来自 A群): 原始内容
                        // 或者直接发送原始内容，为了让操作员回复，我们发送原始内容
                        
                        // 使用 sendMessage 发送文本
                        $forwardText = $msg;
                        // 如果有用户名，带上用户名方便区分
                        $senderName = $user_name ?: '未知用户';
                        // $forwardText = "来自 {$senderName} 的订单:\n" . $msg; 
                        // 为了方便计算距离，直接发原始文本最好，或者只发原始文本
                        
                        // 发送并获取新消息ID
                        $tokenRow = Db::name('robotconfig')->where('name','token')->find();
                        $token = $tokenRow['data'];
                        
                        // 发送
                        $url = "https://api.telegram.org/bot{$token}/sendMessage";
                        $postData = [
                            'chat_id' => $targetGroupId,
                            'text' => $forwardText
                        ];
                        
                        $ch = curl_init();
                        curl_setopt($ch, CURLOPT_URL, $url);
                        curl_setopt($ch, CURLOPT_POST, 1);
                        curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);
                        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                        $res = json_decode(curl_exec($ch), true);
                        curl_close($ch);
                        
                        // 关键：把新消息ID和原始内容存入 Redis
                        if (isset($res['ok']) && $res['ok']) {
                            $newMsgId = $res['result']['message_id'];
                            $cacheKey = "tg_msg:{$targetGroupId}:{$newMsgId}";
                            \think\facade\Cache::store('redis')->set($cacheKey, $msg, 86400);
                        }
                    }
                }
            }

            // 查卡功能
            if (preg_match('/^(查卡|ck|c)\s*(\d+)$/i', $msg, $matches)) {
                $cardNo = $matches[2];
                // Alipay API
                $url = "https://ccdcapi.alipay.com/validateAndCacheCardInfo.json?cardNo={$cardNo}&cardBinCheck=true";
                $res = get_http($url);
                
                if (isset($res['stat']) && $res['stat'] == 'ok' && $res['validated']) {
                    $bankCode = $res['bank'];
                    $cardType = $res['cardType']; // DC=储蓄卡, CC=信用卡
                    
                    // Parse bank list
                    $bankName = $bankCode; // Default to code
                    
                    // Try to query from database first
                    try {
                        $bankRow = Db::name('bank_code')->where('code', $bankCode)->find();
                        if ($bankRow) {
                            $bankName = $bankRow['name'];
                        } else {
                            // Fallback to text file if not found in DB
                            $lines = file(app()->getRootPath() . '银行代码.txt');
                            foreach ($lines as $line) {
                                if (preg_match('/^\s*\d+\s+([A-Z\s]+)([\x{4e00}-\x{9fa5}].*)$/u', $line, $m)) {
                                    $code = trim(str_replace(' ', '', $m[1]));
                                    $name = trim($m[2]);
                                    if ($code == $bankCode) {
                                        $bankName = $name;
                                        break;
                                    }
                                }
                            }
                        }
                    } catch (\Throwable $e) {
                        // Fallback to text file on DB error
                        $lines = file(app()->getRootPath() . '银行代码.txt');
                        foreach ($lines as $line) {
                            if (preg_match('/^\s*\d+\s+([A-Z\s]+)([\x{4e00}-\x{9fa5}].*)$/u', $line, $m)) {
                                $code = trim(str_replace(' ', '', $m[1]));
                                $name = trim($m[2]);
                                if ($code == $bankCode) {
                                    $bankName = $name;
                                    break;
                                }
                            }
                        }
                    }
                    
                    $typeStr = ($cardType == 'DC') ? '储蓄卡' : (($cardType == 'CC') ? '信用卡' : $cardType);
                    
                    $reply = "卡号：{$cardNo}\n";
                    $reply .= "银行：{$bankName}\n";
                    $reply .= "类型：{$typeStr}";
                    
                    huiText($message_id, $groupid, $reply);
                } else {
                    huiText($message_id, $groupid, "❗ 查询失败，请检查卡号是否正确");
                }
                return 'true';
            }
        }

            // 手机号查询
            if (preg_match('/^s\s+(\d{11})$/i', $msg, $matches)) {
                $phone = $matches[1];
                // 使用 360 API (返回 JSON，稳定且无需转码)
                $url = "https://cx.shouji.360.cn/phonearea.php?number={$phone}";
                
                // 使用内置 get_http 自动处理 JSON
                $res = get_http($url);
                
                if (isset($res['code']) && $res['code'] == 0 && isset($res['data'])) {
                    $province = $res['data']['province'];
                    $city = $res['data']['city'];
                    $sp = $res['data']['sp'];
                    
                    // 处理直辖市重复显示 (如 北京 北京)
                    $location = ($province == $city) ? $province : "{$province} {$city}";
                    
                    huiText($message_id, $groupid, "📱 手机号：{$phone}\n📍 归属地：{$location}\n🏢 运营商：{$sp}");
                } else {
                    huiText($message_id, $groupid, "❗ 查询失败 (API无响应)");
                }
                return 'true';
            }

            // 身份证查询
            if (preg_match('/^sfz\s+(\d{17}[\dX])$/i', $msg, $matches)) {
                $id = $matches[1];
                // 本地解析 (100% 准确)
                $birth = substr($id, 6, 4) . '-' . substr($id, 10, 2) . '-' . substr($id, 12, 2);
                $sexCode = substr($id, 16, 1);
                $sex = ($sexCode % 2 == 0) ? '女' : '男';
                
                // 省份代码表 (保底方案)
                $provinces = [
                    '11'=>'北京', '12'=>'天津', '13'=>'河北', '14'=>'山西', '15'=>'内蒙古',
                    '21'=>'辽宁', '22'=>'吉林', '23'=>'黑龙江',
                    '31'=>'上海', '32'=>'江苏', '33'=>'浙江', '34'=>'安徽', '35'=>'福建', '36'=>'江西', '37'=>'山东',
                    '41'=>'河南', '42'=>'湖北', '43'=>'湖南', '44'=>'广东', '45'=>'广西', '46'=>'海南',
                    '50'=>'重庆', '51'=>'四川', '52'=>'贵州', '53'=>'云南', '54'=>'西藏',
                    '61'=>'陕西', '62'=>'甘肃', '63'=>'青海', '64'=>'宁夏', '65'=>'新疆',
                    '71'=>'台湾', '81'=>'香港', '82'=>'澳门'
                ];
                $provCode = substr($id, 0, 2);
                $provName = isset($provinces[$provCode]) ? $provinces[$provCode] : '';

                // 尝试 API 查询详细归属地
                $area = "";
                
                // API 1: xygeng
                $res = get_http("https://api.xygeng.cn/one/idcard?id={$id}"); 
                if (isset($res['code']) && $res['code'] == 200 && isset($res['data']['place'])) {
                     $area = $res['data']['place'];
                }
                
                // API 2: uomg (Fallback)
                if (empty($area)) {
                    $res = get_http("https://api.uomg.com/api/idcard?id={$id}");
                    if (isset($res['code']) && $res['code'] == 1 && isset($res['area'])) {
                        $area = $res['area'];
                    }
                }

                // 如果 API 都挂了，使用本地省份
                if (empty($area)) {
                    $area = $provName ? $provName . " (详细地址查询失败)" : "未知地区";
                }
                
                $reply = "💳 身份证：{$id}\n";
                $reply .= "📍 地区：{$area}\n";
                $reply .= "🎂 生日：{$birth}\n";
                $reply .= "⚧ 性别：{$sex}";
                
                huiText($message_id, $groupid, $reply);
                return 'true';
            }

            // OTC Rate Query (z0, k0, w0)
            if (preg_match('/^([zkw])0$/i', $msg, $matches)) {
                $type = strtolower($matches[1]);
                $paymentMap = [
                    'z' => ['aliPay', '支付宝'],
                    'k' => ['bank', '银行卡'],
                    'w' => ['wxPay', '微信']
                ];
                
                $methodCode = $paymentMap[$type][0];
                $methodName = $paymentMap[$type][1];
                
                // OKX Public API
                $t = time() * 1000;
                // side=sell means Merchant Sells USDT (User Buys).
                // Usually for OTC monitoring, people check "Sell" price (Market Price).
                $url = "https://www.okx.com/v3/c2c/tradingOrders/books?t={$t}&quoteCurrency=CNY&baseCurrency=USDT&side=sell&paymentMethod={$methodCode}&userType=all&showTrade=false";
                
                $header = [
                    "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
                    "Accept: application/json"
                ];
                
                $res = get_http($url, $header);
                
                if (isset($res['code']) && $res['code'] == 0 && !empty($res['data']['sell'])) {
                    $list = $res['data']['sell'];
                    $reply = "欧易交易所 OTC {$methodName} 商家实时价格\n\n";
                    
                    $count = 0;
                    foreach ($list as $item) {
                        if ($count >= 15) break;
                        $price = $item['price'];
                        $nickName = $item['nickName'];
                        $reply .= "{$price}   {$nickName}\n";
                        $count++;
                    }
                    
                    huiText($message_id, $groupid, $reply);
                } else {
                    // Try fallback to side=buy if sell is empty? No, usually OKX returns data.
                    // Or maybe try V5 API if V3 fails? V3 is deprecated but often still works for public endpoints.
                    // If fails, show generic error.
                    huiText($message_id, $groupid, "❗ 获取汇率失败，请稍后再试。");
                }
                return 'true';
            }

            // TRC Address Query (Private Chat Only)
            if ($type == 'ydy' && preg_match('/^T[a-zA-Z0-9]{33}$/', $msg)) {
                $address = $msg;
                // 1. Get Account Info
                $accountUrl = "https://apilist.tronscan.org/api/account?address={$address}";
                
                $header = [
                    "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
                    "Accept: application/json"
                ];
                
                $res = get_http($accountUrl, $header);
                
                if (!empty($res) && is_array($res)) {
                    $trxBalance = isset($res['balance']) ? $res['balance'] / 1000000 : 0;
                    $usdtBalance = 0;
                    $usdtContract = "TR7NHqjeKQxGTCi8q8ZY4pL8otSzgjLj6t"; // USDT Contract
                    
                    if (isset($res['trc20token_balances'])) {
                        foreach ($res['trc20token_balances'] as $token) {
                            $tokenId = isset($token['tokenId']) ? $token['tokenId'] : '';
                            $symbol = isset($token['symbol']) ? $token['symbol'] : (isset($token['tokenAbbr']) ? $token['tokenAbbr'] : '');
                            
                            if ($tokenId == $usdtContract || strtoupper($symbol) == 'USDT') {
                                $decimals = isset($token['decimals']) ? $token['decimals'] : 6;
                                $rawBalance = isset($token['balance']) ? $token['balance'] : 0;
                                $usdtBalance = $rawBalance / pow(10, $decimals);
                                break;
                            }
                        }
                    }
                    
                    $txCount = isset($res['totalTransactionCount']) ? $res['totalTransactionCount'] : 0;
                    
                    $reply = "✅ TRC20地址查询\n";
                    $reply .= "地址: {$address}\n";
                    $reply .= "TRX余额: " . number_format($trxBalance, 2) . "\n";
                    $reply .= "USDT余额: " . number_format($usdtBalance, 2) . "\n";
                    $reply .= "交易总数: {$txCount}\n\n";
                    
                    // 2. Get Latest 5 USDT Transactions
                    $transUrl = "https://apilist.tronscan.org/api/token_trc20/transfers?limit=5&start=0&sort=-timestamp&count=true&relatedAddress={$address}&contract_address={$usdtContract}";
                    $transRes = get_http($transUrl, $header);
                    
                    $reply .= "📝 最近5笔USDT记录:\n";
                    
                    if (isset($transRes['token_transfers']) && !empty($transRes['token_transfers'])) {
                        foreach ($transRes['token_transfers'] as $tx) {
                            $amountRaw = isset($tx['quant']) ? $tx['quant'] : 0;
                            $decimals = isset($tx['tokenInfo']['tokenDecimal']) ? $tx['tokenInfo']['tokenDecimal'] : 6;
                            $amount = $amountRaw / pow(10, $decimals);
                            $amountStr = number_format($amount, 2);
                            
                            $ts = isset($tx['block_ts']) ? $tx['block_ts'] : 0;
                            $time = date('m-d H:i', $ts / 1000);
                            
                            $from = isset($tx['from_address']) ? $tx['from_address'] : '';
                            $to = isset($tx['to_address']) ? $tx['to_address'] : '';
                            $status = (isset($tx['finalResult']) && $tx['finalResult'] == 'SUCCESS') ? '✅' : '❌';
                            
                            if ($to == $address) {
                                $dir = "收入";
                                $symbol = "+";
                                $otherAddr = $from;
                            } else {
                                $dir = "支出";
                                $symbol = "-";
                                $otherAddr = $to;
                            }
                            
                            $shortAddr = substr($otherAddr, 0, 4) . '...' . substr($otherAddr, -4);
                            
                            $reply .= "{$time} | {$symbol}{$amountStr} | {$shortAddr} | {$status}\n";
                        }
                    } else {
                        $reply .= "无最近交易记录\n";
                    }
                    
                    huiText($message_id, $groupid, $reply);
                } else {
                     huiText($message_id, $groupid, "❗ 查询失败，该地址可能未激活或网络异常");
                }
                return 'true';
            }

            // 添加地址监听 (仅私聊)
            // 格式: 监听 Txxxx...
            if ($type == 'ydy' && preg_match('/^监听\s*(T[a-zA-Z0-9]{33})$/i', $msg, $matches)) {
                $address = $matches[1];
                
                // 检查是否已经存在
                $exist = Db::name('address_monitor')
                    ->where('tg_id', $groupid) // 私聊中 groupid 就是用户ID
                    ->where('address', $address)
                    ->find();
                
                if ($exist) {
                    huiText($message_id, $groupid, "❗ 该地址已在您的监听列表中");
                } else {
                    Db::name('address_monitor')->insert([
                        'tg_id' => $groupid,
                        'address' => $address,
                        'last_tx_timestamp' => time() * 1000, // 默认从当前时间开始监听，避免把历史交易都推一遍
                        'create_time' => time()
                    ]);
                    huiText($message_id, $groupid, "✅ 添加监听成功！\n地址: {$address}\n\n机器人将每隔一段时间检查该地址的最新USDT变动并通知您。");
                }
                return 'true';
            }

            // 取消地址监听 (仅私聊)
            // 格式: 取消监听 Txxxx... 或 取消监听 全部
            if ($type == 'ydy' && preg_match('/^取消监听\s*(T[a-zA-Z0-9]{33}|全部)$/i', $msg, $matches)) {
                $target = $matches[1];
                
                if ($target == '全部') {
                    Db::name('address_monitor')->where('tg_id', $groupid)->delete();
                    huiText($message_id, $groupid, "✅ 已取消所有地址的监听");
                } else {
                    $res = Db::name('address_monitor')
                        ->where('tg_id', $groupid)
                        ->where('address', $target)
                        ->delete();
                    
                    if ($res) {
                        huiText($message_id, $groupid, "✅ 已取消监听地址: {$target}");
                    } else {
                        huiText($message_id, $groupid, "❗ 未找到该监听地址");
                    }
                }
                return 'true';
            }
            
            // 监听列表 (仅私聊)
            if ($type == 'ydy' && $msg == '监听列表') {
                $list = Db::name('address_monitor')->where('tg_id', $groupid)->select();
                if ($list->isEmpty()) {
                    huiText($message_id, $groupid, "📭 您的监听列表为空");
                } else {
                    $reply = "📋 您的监听地址列表:\n\n";
                    foreach ($list as $k => $v) {
                        $reply .= ($k + 1) . ". <code>" . $v['address'] . "</code>\n";
                    }
                    huiText($message_id, $groupid, $reply);
                }
                return 'true';
            }

        // 距离查询功能 (全员可用 - 免费版) - 支持私聊和群聊
        // 格式1: 距离 起点-终点 (必须用 - 分隔，或者空格)
        // 格式2: 起点-终点 (无 "距离" 前缀)
        // 格式3: 回复某条包含起点的消息，发送终点
        $isDistanceQuery = false;
        $rawOrigin = '';
        $rawDest = '';

        if (preg_match('/^距离\s+(.+?)[\-]+(.+)$/u', $msg, $matches) || preg_match('/^距离\s+(.+?)[\s]+(.+)$/u', $msg, $matches)) {
            $isDistanceQuery = true;
            $rawOrigin = isset($matches[1]) ? $matches[1] : '';
            $rawDest = isset($matches[2]) ? $matches[2] : '';
        } elseif (preg_match('/^(.+?)[\-]+(.+)$/u', $msg, $matches)) {
            $p1 = isset($matches[1]) ? $matches[1] : '';
            $p2 = isset($matches[2]) ? $matches[2] : '';
            // 排除纯数字、日期格式、命令等
            if (mb_strlen($p1) > 1 && mb_strlen($p2) > 1 && !preg_match('/^\d+$/', $p1) && !is_numeric($msg) && strpos($msg, '/') === false) {
                 $isDistanceQuery = true;
                 $rawOrigin = $p1;
                 $rawDest = $p2;
            }
        } elseif (!empty($params['message']['reply_to_message'])) {
             // 兼容 Text 和 Caption (防止对方发的是图片消息)
             $replyPayload = $params['message']['reply_to_message'];
             $replyText = isset($replyPayload['text']) ? $replyPayload['text'] : (isset($replyPayload['caption']) ? $replyPayload['caption'] : '');
             
             // 【黑科技】如果 API 没给内容，尝试从 Redis 缓存里捞
             if (empty($replyText) && !empty($replyPayload['message_id'])) {
                 $replyMsgId = $replyPayload['message_id'];
                 $cacheKey = "tg_msg:{$groupid}:{$replyMsgId}";
                 $cachedMsg = \think\facade\Cache::store('redis')->get($cacheKey);
                 if (!empty($cachedMsg)) {
                     $replyText = $cachedMsg;
                     // Log::info("成功从Redis找回消失的消息: ID {$replyMsgId}, 内容: {$replyText}");
                 }
             }

             $replyText = trim($replyText);
             
             $currentText = trim($msg);
             
             // 过滤掉明显的非地址内容 (命令、纯数字、太长)
             $isCmd = function($t) {
                 return preg_match('/^[\/\+\-zZkKwW]/', $t) || preg_match('/^(距离|设置|添加|删除|通知|查卡|上课|下课|开始|关闭|显示|查询)/', $t);
             };
             
             // 这里的修改：
             // 1. 不再检查被回复的消息($replyText)是否是命令或数字。因为被回复的消息可能是乱七八糟的报单格式，只要我们能从中提取出地址就行。
             // 2. 只检查当前发送的消息($currentText)不是命令。
             if (!empty($replyText) && 
                 !$isCmd($currentText) && 
                 !is_numeric($currentText) &&
                 mb_strlen($currentText) < 200) {
                 
                 // 必须看起来像地址 (包含行政区划关键字，或者是知名地名)
                 // 扩充：包含所有省份、直辖市、自治区，以及常见的地理后缀
                 $geoKeywords = '省|市|区|县|镇|乡|村|街道|路|号|大厦|苑|小区|酒店|学校|大学|中学|小学|广场|中心|公园|州|盟|旗|站|机场|道|北京|天津|上海|重庆|河北|山西|辽宁|吉林|黑龙江|江苏|浙江|安徽|福建|江西|山东|河南|湖北|湖南|广东|海南|四川|贵州|云南|陕西|甘肃|青海|内蒙古|广西|西藏|宁夏|新疆|香港|澳门|南宁|广州|深圳|东莞|佛山|中山|珠海|惠州|江门|肇庆';
                 $geoRegex = "/({$geoKeywords})/u";
                 
                 // 只要有一方包含关键字，或者都是短中文(2-6字)，就尝试
                 $hasGeoKw = preg_match($geoRegex, $currentText) || preg_match($geoRegex, $replyText);
                // 宽松模式：只要是中文，长度2-10字，且不含明显非地址字符
                $isShortCn = (preg_match('/^[\x{4e00}-\x{9fa5}]{2,10}$/u', $currentText) && preg_match('/^[\x{4e00}-\x{9fa5}]{2,10}$/u', $replyText));
                
                if ($hasGeoKw || $isShortCn) {
                    $isDistanceQuery = true;
                    
                    // 智能提取算法 V5.0：极简主义
                    $cleanStartAddr = function($raw) use ($geoKeywords) {
                        // 1. 无论如何，先把已知的垃圾词全部干掉
                        $temp = $raw;
                        // 替换所有数字 (不管是不是连着U)
                        $temp = preg_replace('/\d+/', ' ', $temp);
                        // 替换所有干扰词
                        $temp = str_replace(['现金', '现结', '预约', '定金', '尾款', '回口', '上课', '下课', '费率', '汇率', '车费', '口令', '红包', '左右', '明天', '后天', '今天', '上午', '下午', '晚上', '早上', '中午', '分钟', '小时', '点'], ' ', $temp);
                        
                        // 2. 现在只剩下 "河北唐山" 和一些空格了，按空格分割
                        $parts = preg_split('/\s+/', trim($temp));
                        
                        foreach ($parts as $part) {
                            if (empty($part)) continue;
                            // 只要剩下的是中文，而且长度大于1，就是它了！
                            if (preg_match('/[\x{4e00}-\x{9fa5}]{2,}/u', $part)) {
                                return $part;
                            }
                        }
                        
                        return $raw; // 实在不行才返回原话
                    };
                    
                     $rawOrigin = $cleanStartAddr($replyText); // 被回复的是起点 (经过清洗)
                     $rawDest = $currentText; // 当前发的是终点
                 }
             }
        } elseif (preg_match('/^[\x{4e00}-\x{9fa5}]{2,10}$/u', trim($msg)) && !is_numeric(trim($msg))) {
             // 之前是调试逻辑，现在改为：如果没有回复对象，不报错，而是默默退出
             // 或者未来可以在这里扩展"单条消息双地名"的逻辑
        }

        if ($msgtype != 'no' && $isDistanceQuery) {
            // 清理输入，去除可能的 "起点:" "终点:" 前缀
            $originAddr = trim(preg_replace('/^(起点|从)[:：]?\s*/u', '', $rawOrigin));
            $destAddr = trim(preg_replace('/^(终点|到)[:：]?\s*/u', '', $rawDest));
            
            // 1. 使用 腾讯地图 WebService API (免Key版 - 模拟官网请求)
            // 增加 Redis 缓存层，大幅提升速度
            $getTencentGeo = function($addr) {
                // 先查缓存
                $cacheKey = 'geo:' . md5($addr);
                $cached = \think\facade\Cache::store('redis')->get($cacheKey);
                if ($cached) {
                    return json_decode($cached, true);
                }

                $key = 'OB4BZ-D4W3U-B7VVO-4PJWW-6TKDJ-WPB77'; // 腾讯地图官方Demo Key
                $addrEnc = urlencode($addr);
                // 伪造 Referer 提高成功率
                $header = ["Referer: https://lbs.qq.com/"];
                
                // A. 优先尝试 Geocoder (地址解析) - 擅长处理 "省市区" 这类行政区划
                $url = "https://apis.map.qq.com/ws/geocoder/v1/?address={$addrEnc}&key={$key}";
                $res = get_http($url, $header);
                if (isset($res['status']) && $res['status'] == 0 && !empty($res['result']['location'])) {
                    $data = [
                        'location' => $res['result']['location'],
                        'title' => $addr
                    ];
                    // 写入缓存，有效期 7 天
                    \think\facade\Cache::store('redis')->set($cacheKey, json_encode($data), 604800);
                    return $data;
                }
                
                // B. 尝试 Suggestion (地点搜索) - 擅长处理 "酒店"、"大厦" 具体POI
                $url = "https://apis.map.qq.com/ws/place/v1/suggestion?keyword={$addrEnc}&key={$key}";
                $res = get_http($url, $header);
                if (isset($res['status']) && $res['status'] == 0 && !empty($res['data'])) {
                    $data = $res['data'][0];
                    // 写入缓存
                    \think\facade\Cache::store('redis')->set($cacheKey, json_encode($data), 604800);
                    return $data;
                }
                
                return null;
            };

            // 获取起点
            $startInfo = $getTencentGeo($originAddr);
            if (!$startInfo) {
                // 如果第一次识别失败，尝试最后一次暴力提取 (针对 V5.0 清洗失败的情况)
                // 假设 originAddr 还是那一长串，我们只取 "省/市" 前后各几个字
                if (mb_strlen($originAddr) > 10) {
                     if (preg_match('/.{0,4}(河北|北京|天津|上海|重庆|山西|辽宁|吉林|黑龙江|江苏|浙江|安徽|福建|江西|山东|河南|湖北|湖南|广东|海南|四川|贵州|云南|陕西|甘肃|青海|内蒙古|广西|西藏|宁夏|新疆|香港|澳门|南宁|广州|深圳|东莞|佛山|中山|珠海|惠州|江门|肇庆).{0,4}/u', $originAddr, $fallbackMatch)) {
                         $originAddr = $fallbackMatch[0]; // 强行只取省市周围的字
                         $startInfo = $getTencentGeo($originAddr); // 再次尝试
                     }
                }
            }

            if (!$startInfo) {
                huiText($message_id, $groupid, "❗ 无法识别起点：{$originAddr} (请尝试更标准的地址格式)");
                return 'true';
            }
            $fromLat = $startInfo['location']['lat'];
            $fromLng = $startInfo['location']['lng'];
            $fromTitle = $startInfo['title'];

            // 获取终点
            $endInfo = $getTencentGeo($destAddr);
            if (!$endInfo) {
                huiText($message_id, $groupid, "❗ 无法识别终点：{$destAddr} (请尝试更标准的地址格式)");
                return 'true';
            }
            $toLat = $endInfo['location']['lat'];
            $toLng = $endInfo['location']['lng'];
            $toTitle = $endInfo['title'];

            // 2. 腾讯地图 驾车规划
            $routeUrl = "https://apis.map.qq.com/ws/direction/v1/driving/?from={$fromLat},{$fromLng}&to={$toLat},{$toLng}&key=OB4BZ-D4W3U-B7VVO-4PJWW-6TKDJ-WPB77&output=json";
            $header = ["Referer: https://lbs.qq.com/"];
            $routeRes = get_http($routeUrl, $header);

            if (isset($routeRes['status']) && $routeRes['status'] == 0 && !empty($routeRes['result']['routes'])) {
                $route = $routeRes['result']['routes'][0];
                $distance = $route['distance']; // 米
                $duration = $route['duration']; // 分钟
                
                // 格式化距离
                $distStr = ($distance >= 1000) ? round($distance / 1000, 1) . " 公里" : $distance . " 米";
                
                // 格式化时间
                $hours = floor($duration / 60);
                $mins = $duration % 60;
                $timeStr = "";
                if ($hours > 0) $timeStr .= "{$hours} 小时 ";
                $timeStr .= "{$mins} 分钟";
                
                $reply = "🚗 <b>驾车路线规划 (腾讯地图)</b>\n\n";
                $reply .= "起点: {$fromTitle}\n";
                $reply .= "终点: {$toTitle}\n";
                $reply .= "距离: <b>{$distStr}</b>\n";
                $reply .= "预计时间: <b>{$timeStr}</b>\n";
                
                huiText($message_id, $groupid, $reply);
            } else {
                huiText($message_id, $groupid, "❗ 路线规划失败");
            }
            return 'true';
        }
    // } // End if($msgtype!='no') for distance/calc (Temporarily commented out to fix syntax error)

    // 群聊特有逻辑 (操作人管理等)
	    if($type=='group'&&$msgtype!='no'){
        try {
            $msg = trim($msg); // 去除首尾空格

            // 监听/接单指令
            if ($msg == '开启监听' || $msg == '关闭监听' || $msg == '开启接单') {
                $gl = empty($params["message"]['from']['username']) ? '' : $params["message"]['from']['username'];
                $uid = $params["message"]['from']['id'];
                
                // 只有管理员能操作
                if ($this->checkAuth($uid, $gl, $groupid)) {
                    if ($msg == '开启监听') {
                        \think\facade\Cache::store('redis')->sAdd('monitor_source_groups', $groupid);
                        huiText($message_id, $groupid, "✅ 已开启监听模式，本群的地址消息将自动转发到接单群。");
                    } elseif ($msg == '关闭监听') {
                        \think\facade\Cache::store('redis')->sRem('monitor_source_groups', $groupid);
                        huiText($message_id, $groupid, "🚫 已关闭监听模式。");
                    } elseif ($msg == '开启接单') {
                        \think\facade\Cache::store('redis')->set('monitor_target_group', $groupid);
                        huiText($message_id, $groupid, "✅ 已开启接单模式，将接收来自监听群的消息。");
                    }
                    return 'true';
                } else {
                    huiText($message_id, $groupid, "❗ 无操作权限！请联系管理员添加您的权限。");
                    return 'true';
                }
            }

            // 上课/下课 (禁言/解禁)
            if ($msg == '上课' || $msg == '下课') {
                $gl = empty($params["message"]['from']['username']) ? '' : $params["message"]['from']['username'];
                $uid = $params["message"]['from']['id'];

                if ($this->checkAuth($uid, $gl, $groupid)) {
                    $tokenRow = Db::name('robotconfig')->where('name','token')->find();
                    $token = $tokenRow['data'];
                    
                    // 权限设置
                    // True = 允许发送 (解禁/上课)
                    // False = 禁止发送 (禁言/下课)
                    $canSend = ($msg == '上课');
                    
                    $permissions = [
                        'can_send_messages' => $canSend,
                        'can_send_media_messages' => $canSend,
                        'can_send_polls' => $canSend,
                        'can_send_other_messages' => $canSend,
                        'can_add_web_page_previews' => $canSend,
                        'can_change_info' => false,
                        'can_invite_users' => true,
                        'can_pin_messages' => false
                    ];
                    
                    $apiUrl = "https://api.telegram.org/bot{$token}/setChatPermissions";
                    $data = [
                        'chat_id' => $groupid,
                        'permissions' => json_encode($permissions)
                    ];
                    
                    // 使用 cURL POST 发送
                    $ch = curl_init();
                    curl_setopt($ch, CURLOPT_URL, $apiUrl);
                    curl_setopt($ch, CURLOPT_POST, 1);
                    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
                    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                    $res = json_decode(curl_exec($ch), true);
                    curl_close($ch);
                    
                    if (isset($res['ok']) && $res['ok']) {
                        if ($canSend) {
                            $reply = "🟢 <b>上课啦！</b>\n\n全员解除禁言，可以自由发言了。";
                        } else {
                            $reply = "🔴 <b>下课啦！</b>\n\n全员已开启禁言，请休息片刻。";
                        }
                    } else {
                        $reply = "❗ 操作失败，请确保机器人是群管理员且具有【更改群组权限】的权限。";
                    }
                    
                    huiText($message_id, $groupid, $reply);
                } else {
                    $msg = "❗无操作权限！";
                    huiText($message_id, $groupid, $msg);
                }
                return 'true';
            }

                // 添加操作人
            if (preg_match('/^(设置|添加)操作人(?:\s+(@?[\w\d_]+))?$/u', $msg, $matches)) {
                $gl = empty($params["message"]['from']['username']) ? '' : $params["message"]['from']['username'];
                $uid = $params["message"]['from']['id'];
                $glid = Db::name('robotconfig')->where('name', 'gl')->find();
                $pieces = array_map('trim', explode(",", $glid['data']));
                
                if (in_array($gl, $pieces) || in_array($uid, $pieces)) {
                    $target = '';
                    $displayName = '';

                    // 优先使用回复的用户
                    if (!empty($params['message']['reply_to_message'])) {
                        $replyFrom = $params['message']['reply_to_message']['from'];
                        if (!empty($replyFrom['username'])) {
                            $target = $replyFrom['username'];
                            $displayName = "@" . $target;
                        } else {
                            $target = $replyFrom['id'];
                            $displayName = "ID: " . $target;
                        }
                    } 
                    // 其次使用命令参数
                    elseif (!empty($matches[2])) {
                        $target = trim($matches[2], '@');
                        $displayName = "@" . $target;
                    }

                    if ($target) {
                        if (!in_array($target, $pieces)) {
                            $currentOps[] = $target;
                            $newOpsStr = implode(',', array_filter(array_unique($currentOps)));
                            
                            Db::name('group')->where('tg_groupid', $groupid)->update(['operators' => $newOpsStr]);
                            
                            $reply = "添加成功的新操作人\n\n {$displayName}\n\n❗️如操作人未设置用户名请使用回复发言的方式进行设置";
                            huiText($message_id, $groupid, $reply);
                        } else {
                            $reply = "该用户已经是本群操作人\n\n {$displayName}";
                            huiText($message_id, $groupid, $reply);
                        }
                    } else {
                        $reply = "请指定用户名或回复一条消息\n格式：添加操作人 @username";
                        huiText($message_id, $groupid, $reply);
                    }
                } else {
                    $msg = "❗无操作权限！";
                    huiText($message_id, $groupid, $msg);
                }
                return 'true';
            }

            // 删除操作人
            if (preg_match('/^删除操作人(?:\s+(@?[\w\d_]+))?$/u', $msg, $matches)) {
                $gl = empty($params["message"]['from']['username']) ? '' : $params["message"]['from']['username'];
                $uid = $params["message"]['from']['id'];
                
                // 只有管理员或操作人可以执行删除操作
                if ($this->checkAuth($uid, $gl, $groupid)) {
                    $target = '';
                    $displayName = '';

                    // 优先使用回复的用户
                    if (!empty($params['message']['reply_to_message'])) {
                        $replyFrom = $params['message']['reply_to_message']['from'];
                        if (!empty($replyFrom['username'])) {
                            $target = $replyFrom['username'];
                            $displayName = "@" . $target;
                        } else {
                            $target = $replyFrom['id'];
                            $displayName = "ID: " . $target;
                        }
                    } 
                    // 其次使用命令参数
                    elseif (!empty($matches[1])) {
                        $target = trim($matches[1], '@');
                        $displayName = "@" . $target;
                    }

                    if ($target) {
                        $group = Db::name('group')->where('tg_groupid', $groupid)->find();
                        if ($group && !empty($group['operators'])) {
                            $currentOps = array_map('trim', explode(",", $group['operators']));
                            
                            if (in_array($target, $currentOps)) {
                                $newOps = array_diff($currentOps, [$target]);
                                $newOpsStr = implode(',', $newOps);
                                
                                Db::name('group')->where('tg_groupid', $groupid)->update(['operators' => $newOpsStr]);
                                
                                $reply = "✅ 已移除该操作人\n\n {$displayName}";
                                huiText($message_id, $groupid, $reply);
                            } else {
                                $reply = "❗ 该用户不是本群操作人\n\n {$displayName}";
                                huiText($message_id, $groupid, $reply);
                            }
                        } else {
                            $reply = "❗ 本群暂无操作人";
                            huiText($message_id, $groupid, $reply);
                        }
                    } else {
                        $reply = "请指定用户名或回复一条消息\n格式：删除操作人 @username";
                        huiText($message_id, $groupid, $reply);
                    }
                } else {
                    $msg = "❗无操作权限！";
                    huiText($message_id, $groupid, $msg);
                }
                return 'true';
            }

            // 显示账单 (仅管理员/操作人)
            if ($msg == '显示账单') {
                $gl = empty($params["message"]['from']['username']) ? '' : $params["message"]['from']['username'];
                $uid = $params["message"]['from']['id'];
                
                if ($this->checkAuth($uid, $gl, $groupid)) {
                    $this->sendBill($message_id, $groupid);
                } else {
                    $msg = "❗无操作权限！";
                    huiText($message_id, $groupid, $msg);
                }
                return 'true';
            }

            // 查询操作人
            if ($msg == '查询操作人') {
                // 1. 获取全局管理员
                $glid = Db::name('robotconfig')->where('name', 'gl')->find();
                $globalAdmins = $glid ? array_filter(array_map('trim', explode(",", $glid['data']))) : [];

                // 2. 获取本群操作人
                $group = Db::name('group')->where('tg_groupid', $groupid)->find();
                $groupOps = ($group && !empty($group['operators'])) ? array_filter(array_map('trim', explode(",", $group['operators']))) : [];

                $reply = "👮‍♂️ 机器人管理员 (全局):\n";
                if (empty($globalAdmins)) {
                    $reply .= "无\n";
                } else {
                    foreach ($globalAdmins as $admin) {
                        $reply .= (is_numeric($admin) ? "ID: {$admin}" : "@{$admin}") . "\n";
                    }
                }

                $reply .= "\n👷 本群操作人:\n";
                if (empty($groupOps)) {
                    $reply .= "无\n";
                } else {
                    foreach ($groupOps as $op) {
                        $reply .= (is_numeric($op) ? "ID: {$op}" : "@{$op}") . "\n";
                    }
                }

                huiText($message_id, $groupid, $reply);
                return 'true';
            }

            // 添加/删除全局管理员 (仅现有全局管理员可用)
            if (preg_match('/^(添加|删除)管理员(?:\s+(@?[\w\d_]+))?$/u', $msg, $matches)) {
                $gl = empty($params["message"]['from']['username']) ? '' : $params["message"]['from']['username'];
                $uid = $params["message"]['from']['id'];
                
                // 检查是否为全局管理员
                $glid = Db::name('robotconfig')->where('name', 'gl')->find();
                $globalAdmins = $glid ? array_map('trim', explode(",", $glid['data'])) : [];
                
                if (in_array($gl, $globalAdmins) || in_array($uid, $globalAdmins)) {
                    $action = $matches[1];
                    $target = '';
                    $displayName = '';

                    // 优先使用回复的用户
                    if (!empty($params['message']['reply_to_message'])) {
                        $replyFrom = $params['message']['reply_to_message']['from'];
                        if (!empty($replyFrom['username'])) {
                            $target = $replyFrom['username'];
                            $displayName = "@" . $target;
                        } else {
                            $target = $replyFrom['id'];
                            $displayName = "ID: " . $target;
                        }
                    } 
                    // 其次使用命令参数
                    elseif (!empty($matches[2])) {
                        $target = trim($matches[2], '@');
                        $displayName = "@" . $target;
                    }

                    if ($target) {
                        if ($action == '添加') {
                            if (!in_array($target, $globalAdmins)) {
                                $globalAdmins[] = $target;
                                $newListStr = implode(',', array_filter(array_unique($globalAdmins)));
                                
                                if ($glid) {
                                    Db::name('robotconfig')->where('name', 'gl')->update(['data' => $newListStr]);
                                } else {
                                    Db::name('robotconfig')->insert(['name' => 'gl', 'data' => $newListStr]);
                                }
                                $reply = "✅ 已添加新的全局管理员\n\n {$displayName}";
                                huiText($message_id, $groupid, $reply);
                            } else {
                                $reply = "❗ 该用户已经是全局管理员\n\n {$displayName}";
                                huiText($message_id, $groupid, $reply);
                            }
                        } else { // 删除
                            if (in_array($target, $globalAdmins)) {
                                $newAdmins = array_diff($globalAdmins, [$target]);
                                $newListStr = implode(',', $newAdmins);
                                
                                Db::name('robotconfig')->where('name', 'gl')->update(['data' => $newListStr]);
                                $reply = "✅ 已移除全局管理员\n\n {$displayName}";
                                huiText($message_id, $groupid, $reply);
                            } else {
                                $reply = "❗ 该用户不是全局管理员\n\n {$displayName}";
                                huiText($message_id, $groupid, $reply);
                            }
                        }
                    } else {
                        $reply = "请指定用户名或回复一条消息\n格式：{$action}管理员 @username";
                        huiText($message_id, $groupid, $reply);
                    }
                } else {
                    $msg = "❗ 只有全局管理员可以执行此操作！";
                    huiText($message_id, $groupid, $msg);
                }
                return 'true';
            }

            // 设置汇率
            if (preg_match('/^设置汇率\s*([\d\.]+)/', $msg, $matches)) {
                $gl = empty($params["message"]['from']['username']) ? '' : $params["message"]['from']['username'];
                $uid = $params["message"]['from']['id'];
                
                if ($this->checkAuth($uid, $gl, $groupid)) {
                    $newRate = $matches[1];
                    $exist = Db::name('base_config')->where('name', 'rate')->find();
                    if ($exist) {
                        Db::name('base_config')->where('name', 'rate')->update(['data' => $newRate]);
                    } else {
                        Db::name('base_config')->insert(['name' => 'rate', 'data' => $newRate]);
                    }
                    $msg = "✅ 汇率已更新为: " . $newRate;
                    huiText($message_id, $groupid, $msg);
                    
                    // 自动修改群标题
                    $currentTitle = $grouptitle;
                    $newSuffix = " 汇率{$newRate}";
                    
                    // 检查是否已有 "汇率" 后缀
                    // 1. 先尝试移除所有旧的 "汇率xxx" 或 "-汇率xxx" 或 " 汇率xxx"
                    //    支持各种分隔符: 空格, -, |
                    $baseTitle = preg_replace('/[\s\-\|]+汇率\s*[\d\.]+$/u', '', $currentTitle);
                    
                    // 2. 重新拼接
                    $newTitle = $baseTitle . $newSuffix;
                    
                    // 如果新标题与当前标题不同，则尝试更新
                    if ($newTitle != $currentTitle) {
                        $tokenRow = Db::name('robotconfig')->where('name','token')->find();
                        $token = $tokenRow['data'];
                        
                        $apiUrl = "https://api.telegram.org/bot{$token}/setChatTitle";
                        $postData = [
                            'chat_id' => $groupid,
                            'title' => $newTitle
                        ];
                        
                        // 发送请求
                        $ch = curl_init();
                        curl_setopt($ch, CURLOPT_URL, $apiUrl);
                        curl_setopt($ch, CURLOPT_POST, 1);
                        curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);
                        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                        $res = json_decode(curl_exec($ch), true);
                        curl_close($ch);
                        
                        if (!isset($res['ok']) || !$res['ok']) {
                            // 失败通常是因为机器人不是管理员或没有change_info权限
                            huiText($message_id, $groupid, "⚠️ 尝试修改群名失败，请检查机器人是否为管理员及是否有“更改群组信息”权限。");
                        }
                    }
                } else {
                    $msg = "❗无操作权限！";
                    huiText($message_id, $groupid, $msg);
                }
                return 'true';
            }

            // 设置日切时间
            if (preg_match('/^设置日切时间\s*(\d{1,2})[:：](\d{2})$/u', $msg, $matches)) {
                $gl = empty($params["message"]['from']['username']) ? '' : $params["message"]['from']['username'];
                $uid = $params["message"]['from']['id'];
                
                if ($this->checkAuth($uid, $gl, $groupid)) {
                    $hour = str_pad($matches[1], 2, '0', STR_PAD_LEFT);
                    $minute = str_pad($matches[2], 2, '0', STR_PAD_LEFT);
                    
                    if ($hour >= 0 && $hour <= 23 && $minute >= 0 && $minute <= 59) {
                        $timeStr = "{$hour}:{$minute}";
                        
                        // Check if column exists (User needs to run SQL, but we try to update)
                        // Assuming column exists as per instructions to user later.
                        
                        $group = Db::name('group')->where('tg_groupid', $groupid)->find();
                        if ($group) {
                            Db::name('group')->where('tg_groupid', $groupid)->update(['cutoff_time' => $timeStr]);
                            $msg = "✅ 本群日切时间已设置为: {$timeStr}";
                        } else {
                            $data = ['tg_groupid' =>$groupid, 'name' => $grouptitle, 'cutoff_time' => $timeStr];
                            Db::name('group')->insert($data);
                            $msg = "✅ 本群日切时间已设置为: {$timeStr}";
                        }
                    } else {
                        $msg = "❗ 时间格式错误，请输入正确的时间 (00:00 - 23:59)";
                    }
                    huiText($message_id, $groupid, $msg);
                } else {
                    $msg = "❗无操作权限！";
                    huiText($message_id, $groupid, $msg);
                }
                return 'true';
            }

            // 开始命令
    		if ($msg == '开始') {
                $gl = empty($params["message"]['from']['username']) ? '' : $params["message"]['from']['username'];
                $uid = $params["message"]['from']['id']; 

                if ($this->checkAuth($uid, $gl, $groupid)) {
                    // 日切逻辑
                    $now = time();
                    $cutoffTime = $this->getGroupCutoff($groupid);
                    $todayCutoff = strtotime(date('Y-m-d ' . $cutoffTime . ':00'));
                    
                    if ($now < $todayCutoff) {
                        $start = strtotime(date('Y-m-d ' . $cutoffTime . ':00', strtotime('-1 day')));
                        $end = $todayCutoff;
                    } else {
                        $start = $todayCutoff;
                        $end = strtotime(date('Y-m-d ' . $cutoffTime . ':00', strtotime('+1 day')));
                    }

                    // 检查是否已经开始
                    $hasStarted = Db::name('order')
                        ->where('group_id', $groupid)
                        ->where('zd', 2)
                        ->where('rltime', '>=', $start)
                        ->where('rltime', '<', $end)
                        ->find();

                    if ($hasStarted) {
                        $msg = "❗ 今日记账已开启，无需重复操作";
                        huiText($message_id, $groupid, $msg);
                    } else {
                        // 插入开始标记 (zd=2)
                        $orderdata = [
                            'amount' => 0, 
                            'zd' => 2, // 2代表开始标记
                            'group_id' => $groupid, 
                            'rl' => 1, 
                            'tgid' => $user_id, 
                            'tgname' => $user_name, 
                            'group_name' => $grouptitle, 
                            'rltime' => time()
                        ];
                        Db::name('order')->insert($orderdata);
                        
                        $dateStr = ($now < $todayCutoff) ? date('Y-m-d', strtotime('-1 day')) : date('Y-m-d');
                        $msg = "✅ 已开启 {$dateStr} 的记账 (日切时间: {$cutoffTime})";
                        huiText($message_id, $groupid, $msg);
                    }
                } else {
                    $msg = "❗无操作权限！";
                    huiText($message_id, $groupid, $msg);
                }
                return 'true';
            }

            // 关闭记账命令
            if ($msg == '关闭记账') {
                $gl = empty($params["message"]['from']['username']) ? '' : $params["message"]['from']['username'];
                $uid = $params["message"]['from']['id']; 

                if ($this->checkAuth($uid, $gl, $groupid)) {
                    // 日切逻辑
                    $now = time();
                    $cutoffTime = $this->getGroupCutoff($groupid);
                    $todayCutoff = strtotime(date('Y-m-d ' . $cutoffTime . ':00'));
                    
                    if ($now < $todayCutoff) {
                        $start = strtotime(date('Y-m-d ' . $cutoffTime . ':00', strtotime('-1 day')));
                        $end = $todayCutoff;
                    } else {
                        $start = $todayCutoff;
                        $end = strtotime(date('Y-m-d ' . $cutoffTime . ':00', strtotime('+1 day')));
                    }

                    // 查找当前周期的开始标记
                    $hasStarted = Db::name('order')
                        ->where('group_id', $groupid)
                        ->where('zd', 2)
                        ->where('rltime', '>=', $start)
                        ->where('rltime', '<', $end)
                        ->find();

                    if ($hasStarted) {
                        // 删除开始标记
                        Db::name('order')->where('id', $hasStarted['id'])->delete();
                        $msg = "✅ 关闭记账成功";
                        huiText($message_id, $groupid, $msg);
                    } else {
                        $msg = "❗ 未开始记账";
                        huiText($message_id, $groupid, $msg);
                    }
                } else {
                    $msg = "❗无操作权限！";
                    huiText($message_id, $groupid, $msg);
                }
                return 'true';
            }

            // 通知所有人
            if ($msg == '通知所有人') {
                $gl = empty($params["message"]['from']['username']) ? '' : $params["message"]['from']['username'];
                $uid = $params["message"]['from']['id']; 

                if ($this->checkAuth($uid, $gl, $groupid)) {
                    $tokenRow = Db::name('robotconfig')->where('name','token')->find();
                    $token = $tokenRow['data'];

                    $userMap = [];

                    // 1. 获取 member 表 (优先使用，包含 username)
                    try {
                        $members = Db::name('member')->where('group_id', $groupid)->select();
                        foreach ($members as $m) {
                            $userMap[$m['tgid']] = [
                                'name' => $m['tgname'], 
                                'username' => isset($m['username']) ? $m['username'] : ''
                            ];
                        }
                    } catch (\Exception $e) {
                        // Table or column might not exist yet
                    }

                    // 2. 获取 order 表 (补充历史用户)
                    $orders = Db::name('order')
                        ->where('group_id', $groupid)
                        ->where('tgid', '>', 0)
                        ->group('tgid')
                        ->column('tgname', 'tgid');
                    
                    foreach ($orders as $oid => $oname) {
                        if (!isset($userMap[$oid])) {
                            $userMap[$oid] = ['name' => $oname, 'username' => ''];
                        }
                    }

                    // 3. 获取管理员列表
                    $adminUrl = "https://api.telegram.org/bot{$token}/getChatAdministrators?chat_id={$groupid}";
                    $adminRes = get_http($adminUrl);
                    if (isset($adminRes['ok']) && $adminRes['ok']) {
                        foreach ($adminRes['result'] as $admin) {
                            $aid = $admin['user']['id'];
                            $aname = isset($admin['user']['first_name']) ? $admin['user']['first_name'] : "管理员";
                            $ausername = isset($admin['user']['username']) ? $admin['user']['username'] : '';
                            
                            // 覆盖或添加管理员信息 (管理员的 username 最准确)
                            $userMap[$aid] = ['name' => $aname, 'username' => $ausername];
                        }
                    }

                    if (empty($userMap)) {
                        huiText($message_id, $groupid, "❗ 本群暂无用户记录");
                        return 'true';
                    }
                    
                    $mentions = [];
                    foreach ($userMap as $tid => $info) {
                        if (!empty($info['username'])) {
                            // 使用 @username 格式
                            $mentions[] = "@" . $info['username'];
                        } else {
                            // 无用户名，使用文本链接格式
                            $safeName = htmlspecialchars($info['name'], ENT_QUOTES);
                            if (empty($safeName)) $safeName = "用户";
                            $mentions[] = "<a href=\"tg://user?id={$tid}\">{$safeName}</a>";
                        }
                    }
                    
                    // 分批发送
                    $chunks = array_chunk($mentions, 20);
                    $sentMsgIds = [];
                    
                    foreach ($chunks as $chunk) {
                        $text = "📢 <b>通知所有人</b>\n\n" . implode(" ", $chunk);
                        $apiUrl = "https://api.telegram.org/bot{$token}/sendMessage?chat_id={$groupid}&text=" . urlencode($text) . "&parse_mode=HTML";
                        
                        $res = get_http($apiUrl);
                        if (isset($res['ok']) && $res['ok']) {
                            $sentMsgIds[] = $res['result']['message_id'];
                        }
                    }
                    
                    // 延迟删除 (30秒)
                    if (!empty($sentMsgIds)) {
                        if (function_exists('fastcgi_finish_request')) {
                            fastcgi_finish_request();
                        }
                        
                        sleep(30);
                        
                        foreach ($sentMsgIds as $mid) {
                            $delUrl = "https://api.telegram.org/bot{$token}/deleteMessage?chat_id={$groupid}&message_id={$mid}";
                            get_http($delUrl);
                        }
                    }
                } else {
                    $msg = "❗无操作权限！";
                    huiText($message_id, $groupid, $msg);
                }
                return 'true';
            }

            // 查询被回复用户的账单
            if (!empty($params["message"]['reply_to_message']) && trim($msg) == '账单') {
                $targetUserId = $params["message"]['reply_to_message']['from']['id'];
                $firstName = isset($params['message']['reply_to_message']['from']['first_name']) ? $params['message']['reply_to_message']['from']['first_name'] : '';
                $lastName = isset($params['message']['reply_to_message']['from']['last_name']) ? $params['message']['reply_to_message']['from']['last_name'] : '';
                $targetUserName = $firstName . $lastName;
                if (empty($targetUserName) && isset($params['message']['reply_to_message']['from']['username'])) {
                    $targetUserName = $params['message']['reply_to_message']['from']['username'];
                }

                // 日切逻辑
                $now = time();
                $cutoffTime = $this->getGroupCutoff($groupid);
                $todayCutoff = strtotime(date('Y-m-d ' . $cutoffTime . ':00'));
                
                if ($now < $todayCutoff) {
                    $start = strtotime(date('Y-m-d ' . $cutoffTime . ':00', strtotime('-1 day')));
                    $end = $todayCutoff;
                } else {
                    $start = $todayCutoff;
                    $end = strtotime(date('Y-m-d ' . $cutoffTime . ':00', strtotime('+1 day')));
                }

                // 获取汇率
                $rateConfig = Db::name('base_config')->where('name', 'rate')->find();
                $baseRate = $rateConfig ? $rateConfig['data'] : 12.8;

                $orders = Db::name('order')
                    ->where('group_id', $groupid)
                    ->where('tgid', $targetUserId)
                    ->where('rltime', '>=', $start)
                    ->where('rltime', '<', $end)
                    ->where('amount', '<>', 0)
                    ->order('rltime', 'desc')
                    ->select();

                $incomeCount = 0;
                $incomeTotal = 0;
                $incomeUsdtTotal = 0;
                $incomeLines = [];

                $outcomeTotal = 0;
                $outcomeUsdtTotal = 0;

                foreach ($orders as $v) {
                    $amount = floatval($v['amount']);
                    $usdt = isset($v['usdt']) && $v['usdt'] != 0 ? floatval($v['usdt']) : ($baseRate > 0 ? round(abs($amount) / $baseRate, 3) : 0);
                    $rate = ($usdt != 0) ? round(abs($amount) / abs($usdt), 2) : $baseRate;
                    $timeStr = date('H:i', $v['rltime']);

                    if ($amount > 0) {
                        $incomeCount++;
                        $incomeTotal += $amount;
                        $incomeUsdtTotal += $usdt;
                        $incomeLines[] = "{$timeStr} {$amount}/{$rate} = {$usdt}u";
                    } else {
                        $outcomeTotal += abs($amount);
                        $outcomeUsdtTotal += abs($usdt);
                    }
                }

                $reply = "用户：@{$targetUserName}\n";
                $reply .= "入款笔数：{$incomeCount}\n\n";
                $reply .= "入款明细：\n";
                
                if (empty($incomeLines)) {
                    $reply .= "无\n";
                } else {
                    $showLines = array_slice($incomeLines, 0, 5);
                    $reply .= implode("\n", $showLines) . "\n";
                    if (count($incomeLines) > 5) {
                        $reply .= "...\n";
                    }
                }
                $reply .= "\n";
                
                $remainingUsdt = round($incomeUsdtTotal - $outcomeUsdtTotal, 2);
                
                $reply .= "入款总金额：{$incomeTotal} | {$incomeUsdtTotal} U\n";
                $reply .= "下发总金额：{$outcomeTotal} | {$outcomeUsdtTotal} U\n";
                $reply .= "未回合计：{$remainingUsdt} U";

                if (count($incomeLines) > 5) {
                    $seturl = Db::name('base_config')->where('name','domain')->find();
                    $url = $seturl['data'] . '/index/order/jr?groupid=' . $groupid;
                    huiText($message_id, $groupid, $reply, '点击跳转完整账单', $url);
                } else {
                    huiText($message_id, $groupid, $reply);
                }
                return 'true'; // Return string 'true' to stop further processing
            }

            // 删除账单
            if ($msg == '删除账单') {
                $gl = empty($params["message"]['from']['username']) ? '' : $params["message"]['from']['username'];
                $uid = $params["message"]['from']['id'];
                
                if ($this->checkAuth($uid, $gl, $groupid)) {
                    if (!empty($params["message"]['reply_to_message'])) {
                        $replyMsg = $params["message"]['reply_to_message'];
                        $replyText = isset($replyMsg['text']) ? $replyMsg['text'] : '';
                        $replyUserId = isset($replyMsg['from']['id']) ? $replyMsg['from']['id'] : 0;
                        
                        if ($replyText) {
                            // 解析回复的消息内容以查找对应订单
                            $zl = substr($replyText, 0, 1);
                            $is_xiafa = (strpos($replyText, '下发') === 0);
                            
                            if ($zl == '+' || $zl == '-' || $is_xiafa) {
                                // 尝试解析金额
                                if ($is_xiafa) {
                                    $msgVal = trim(str_replace('下发', '', $replyText));
                                } else {
                                    $msgVal = trim(substr($replyText, 1));
                                }
                                
                                // 获取当时可能使用的汇率（这里只能尽量匹配金额）
                                // 实际上我们只需要匹配金额和用户
                                // 解析逻辑需要一致
                                $rateConfig = Db::name('base_config')->where('name', 'rate')->find();
                                $baseRate = $rateConfig ? $rateConfig['data'] : 12.8;
                                $usedRate = $baseRate;
                                
                                $amount = 0;
                                if (preg_match('/^(\d+(\.\d+)?)u$/i', $msgVal, $match)) {
                                    $uAmount = $match[1];
                                    $amount = $uAmount * $usedRate;
                                } elseif (strpos($msgVal, '/') !== false) {
                                    $parts = explode('/', $msgVal);
                                    if (count($parts) == 2 && is_numeric(trim($parts[0])) && is_numeric(trim($parts[1]))) {
                                        $amount = trim($parts[0]);
                                    } else {
                                         if (preg_match('/^(\d+(\.\d+)?)\s*\/\s*(\d+(\.\d+)?)$/', $msgVal, $match)) {
                                            $amount = $match[1];
                                         } else {
                                            $amount = floatval($msgVal);
                                         }
                                    }
                                } else {
                                    $amount = $msgVal;
                                }
                                
                                $is_outcome = ($zl == '-' || $is_xiafa);
                                $finalAmount = ($is_outcome) ? -1 * abs($amount) : abs($amount);
                                
                                // 查找最近的一笔匹配订单
                                // 条件：群ID，用户ID，金额，且未被删除(这里假设直接物理删除)
                                // 注意：如果回复的是直发命令，tgid可能为0，但reply_to_message有from id
                                // 之前的逻辑：如果是直发，tgid存的是0（toid）。如果是回复加账，tgid存的是被回复人的ID。
                                // 这里删除账单，如果是管理员发的命令，tgid可能是0？
                                // 不，groupgl里：
                                // 直发：$this->groupgl(..., $toid=0, $toname='0'); -> tgid=0
                                // 回复：$this->groupgl(..., $toid=被回复人ID, ...); -> tgid=被回复人ID
                                
                                // 情况1：管理员直接发 "+100"，tgid=0. Admin replies to this msg. 
                                // The msg is from Admin. reply_to_message['from']['id'] is Admin's ID.
                                // But DB has tgid=0. So we might fail to match tgid if we look for AdminID.
                                
                                // 情况2：用户A发 "+100" (User can't add?). Only admins can add.
                                // Wait, the code says: "判断发送人是不是管理员". Only admins can trigger groupgl.
                                // If admin replies to User A with "+100", tgid = User A.
                                // If admin sends "+100" directly, tgid = 0.
                                
                                // So, if reply_to_message was a direct command from an Admin:
                                // The sender of that msg is the Admin.
                                // But the order in DB has tgid=0.
                                // So if we search by tgid=AdminID, we won't find it.
                                
                                // We should try to find with tgid=0 OR tgid=replyUserId.
                                // And strictly match amount and group_id.
                                
                                $order = Db::name('order')
                                    ->where('group_id', $groupid)
                                    ->where('amount', $finalAmount)
                                    ->where(function ($query) use ($replyUserId) {
                                        $query->where('tgid', $replyUserId)->whereOr('tgid', 0);
                                    })
                                    ->order('id', 'desc')
                                    ->find();
                                    
                                if ($order) {
                                    Db::name('order')->delete($order['id']);
                                    $msg = "🗑️ 已删除订单 (ID: {$order['id']}, 金额: {$finalAmount})";
                                    huiText($message_id, $groupid, $msg);
                                    
                                    // 重新显示账单
                                    $this->sendBill($message_id, $groupid);
                                } else {
                                    $msg = "❗ 未找到匹配的订单 (可能是金额不匹配或已被删除)";
                                    huiText($message_id, $groupid, $msg);
                                }
                            } else {
                                $msg = "❗ 请回复一条有效的记账命令";
                                huiText($message_id, $groupid, $msg);
                            }
                        }
                    } else {
                        $msg = "❗ 请回复需要删除的账单消息";
                        huiText($message_id, $groupid, $msg);
                    }
                } else {
                    $msg = "❗无操作权限！";
                    huiText($message_id, $groupid, $msg);
                }
                return 'true';
            }

	    if(!empty($params["message"]['reply_to_message'])){
            // 检查是否在前面已经处理了特定回复逻辑 (如"账单" 或 "删除账单" 或 "添加操作人")
            // 如果已经在前面返回了 'true'，这里就不会执行
            // 但 Tg::message() 是顺序执行的，前面 return 'true' 会结束函数。
            // 问题在于：前面的 if 块没有覆盖所有 reply 情况，或者某些逻辑漏了 return
            
            // 让我们检查一下前面的逻辑：
            // "删除账单" -> return 'true' (已处理)
            // "添加操作人" -> return 'true' (已处理)
            // "回复账单" -> return 'true' (已处理)
            
            // 那么剩下的就是 "上下分操作" (回复加款/下发)
            // 或者是普通回复消息
            
	        $toid=$params["message"]['reply_to_message']['from']['id'];
	        $toname=(empty($params["message"]['reply_to_message']['from']['first_name'])?'':$params["message"]['reply_to_message']['from']['first_name']).(empty($params["message"]['reply_to_message']['from']['last_name'])?'':$params["message"]['reply_to_message']['from']['last_name']);
	        //判断发送人是不是管理员
	        $gl=empty($params["message"]['from']['username'])?'':$params["message"]['from']['username'];
            $uid = $params["message"]['from']['id'];
            
	        if ($this->checkAuth($uid, $gl, $groupid)) {
	            $this->groupgl($message_id,$groupid,$grouptitle,$msgtype,$msg,$xin,$user_id,$user_name,$toid,$toname);
	        }else{
	            $msg="❗无操作权限！";
                huiText($message_id,$groupid,$msg);
	        }
	    }else{
            // 检查是否为直发 +金额/-金额/下发金额 命令
            $is_direct_order = false;
            // 检查是否在前面已经处理过 (return 'true' 会直接结束)
            
            if ($msgtype == 'text') {
                $zl = substr($msg, 0, 1);
                $is_xiafa = (strpos($msg, '下发') === 0);
                
                if ($zl == '+' || $zl == '-' || $is_xiafa) {
                    // 判断是否是管理员
                    $gl = empty($params["message"]['from']['username']) ? '' : $params["message"]['from']['username'];
                    $uid = $params["message"]['from']['id'];
                    
                    if ($this->checkAuth($uid, $gl, $groupid)) {
                        $is_direct_order = true;
                        // 直接加账，目标用户ID为0，用户名为0
                        $this->groupgl($message_id, $groupid, $grouptitle, $msgtype, $msg, $xin, $user_id, $user_name, 0, '0');
                    } else {
                        // 权限不足提示 (避免无反应)
                        $msg = "❗无操作权限！";
                        huiText($message_id, $groupid, $msg);
                        // 标记为已处理，防止进入group()
                        $is_direct_order = true; 
                    }
                }
            }

            if (!$is_direct_order) {
	        $this->group($message_id,$groupid,$grouptitle,$msgtype,$msg,$xin,$user_id,$user_name); 
	    }
        }
            } catch (\Throwable $e) {
                $errMsg = "❌ 系统错误: " . $e->getMessage() . " line:" . $e->getLine();
                huiText($message_id, $groupid, $errMsg);
	    }
	        return 'true';
	    }else{
	        if($msgtype=='photo'){
	           $this->ydy($groupid,$msg);
	        }
	        return 'true';
	    }
	    
        // $welcome_text = preg_replace('/^ +/m', '',
        //         "{$forwardArr['text']}"
        //     );
        // sendText($chat_id,$welcome_text);
	}
	//群消息处理
	function group($message_id,$groupid,$grouptitle,$msgtype,$msg,$xin,$user_id,$user_name){
	    if($msgtype=='text'){
    	       //判断是否有这个群
                $group=Db::name('group')->where('tg_groupid',$groupid)->find();
                if(empty($group)){
                    $data = ['tg_groupid' =>$groupid, 'name' => $grouptitle];
                    Db::name('group')->insert($data);
                }else{
                    Db::name('group')->where('tg_groupid',$groupid)->update(['name'=>$grouptitle]);
                }
                 //判断是否有这个用户 (Global User Table)
                $user=Db::name('user')->where('tguid',$user_id)->find();
	            if(empty($user)){
	                $dataa = ['tguid' =>$user_id, 'tgname' => $user_name];
                    Db::name('user')->insert($dataa);
	            }else{
	                Db::name('user')->where('tguid',$user_id)->update(['tgname'=>$user_name]);
	            }

                // 记录群成员 (New Group Member Tracking)
                if (!empty($user_id)) {
                    try {
                        $tg_username = isset($params['message']['from']['username']) ? $params['message']['from']['username'] : '';
                        
                        // 检查表是否存在 (简单方法是直接查，如果报错catch住)
                        $member = Db::name('member')
                            ->where('group_id', $groupid)
                            ->where('tgid', $user_id)
                            ->find();
                        
                        if (!$member) {
                            Db::name('member')->insert([
                                'group_id' => $groupid,
                                'tgid' => $user_id,
                                'tgname' => $user_name,
                                'username' => $tg_username,
                                'createtime' => time()
                            ]);
                        } else {
                            // Update info if changed
                            $updateData = [];
                            if ($member['tgname'] != $user_name) $updateData['tgname'] = $user_name;
                            // Check if username column exists in result
                            if (array_key_exists('username', $member) && $member['username'] != $tg_username) {
                                $updateData['username'] = $tg_username;
                            }
                            
                            if (!empty($updateData)) {
                                Db::name('member')->where('id', $member['id'])->update($updateData);
                            }
                        }
                    } catch (\Throwable $e) {
                        // 忽略 member 表相关错误，防止影响主流程
                        Log::error("Member tracking failed: " . $e->getMessage());
                    }
                }

    	    //拆分关键词玩法明 和金额
    		$zl=substr($msg, 0, 1 );
    		
    		if($zl=='/'){
    		    if (strpos($msg, '@') !== false) {
                    $msg=substr($msg,0,strpos($msg, '@'));
                }
    		    $msg = substr($msg, 1);
    		    preg_match_all('/^([^\d]+)(\d+)/', $msg, $match);
    		    if($msg=='today'){
    		    //查询本群今日所有人汇总
    		    //自动正常
    		    $zdz=Db::name('order')->whereDay('rltime')->where('group_id',$groupid)->where('zd',0)->where('dj',0)->where('rl',1)->count();
    		    $zdzj=Db::name('order')->whereDay('rltime')->where('group_id',$groupid)->where('zd',0)->where('dj',0)->where('rl',1)->sum('amount');
    		    //自动冻结
    		    $zdd=Db::name('order')->whereDay('rltime')->where('group_id',$groupid)->where('zd',0)->where('dj',1)->where('rl',1)->count();
    		    $zddj=Db::name('order')->whereDay('rltime')->where('group_id',$groupid)->where('zd',0)->where('dj',1)->where('rl',1)->sum('amount');
    		    //手动正常
    		    $sdz=Db::name('order')->whereDay('rltime')->where('group_id',$groupid)->where('zd',1)->where('dj',0)->where('rl',1)->count();
    		    $sdzj=Db::name('order')->whereDay('rltime')->where('group_id',$groupid)->where('zd',1)->where('dj',0)->where('rl',1)->sum('amount');
    		    //手动冻结
    		    $sdd=Db::name('order')->whereDay('rltime')->where('group_id',$groupid)->where('zd',1)->where('dj',1)->where('rl',1)->count();
    		    $sddj=Db::name('order')->whereDay('rltime')->where('group_id',$groupid)->where('zd',1)->where('dj',1)->where('rl',1)->sum('amount');
    		    //查询所有用户
    		    $userdata=Db::name('user')->select();
    		    $usera='';
    		    if(!empty($userdata)&&$zdz>0){
    		         foreach ($userdata as $i) {
        		        $zcje=Db::name('order')->whereDay('rltime')->where('group_id',$groupid)->where('tgid',$i['tguid'])->where('rl',1)->where('dj',0)->sum('amount');
        		        $djje=Db::name('order')->whereDay('rltime')->where('group_id',$groupid)->where('tgid',$i['tguid'])->where('rl',1)->where('dj',1)->sum('amount');
        		        if($zcje!=0||$djje!=0){
        		            $usera=$usera.$i['tgname']." 正常:".$zcje." 冻结:".$djje."\n";
        		        }
        		        
        		    }
    		    }else{
    		        $usera='空';
    		    }
    		    //查询域名
        		    $seturl=Db::name('base_config')->where('name','domain')->find();
                    $hdurl=$seturl['data'].'/index/order/jr?groupid='.$groupid;
    		    //查询群用户明细
    		     $msg="本群".date("Y-m-d")."的汇总\n🔱自动入账:\n正常: ".$zdzj." (".$zdz."笔)\n冻结: ".$zddj." (".$zdd."笔)\n\n🔆手动入账:\n正常: ".$sdzj." (".$sdz."笔)\n冻结: ".$sddj." (".$sdd."笔)\n\n🚻用户汇总🚻\n".$usera."\n";
    		    }elseif($msg=='yesterday'){
    		    //查询本群昨日所有人汇总
    		        $zdz=Db::name('order')->whereDay('rltime', 'yesterday')->where('group_id',$groupid)->where('zd',0)->where('dj',0)->where('rl',1)->count();
        		    $zdzj=Db::name('order')->whereDay('rltime', 'yesterday')->where('group_id',$groupid)->where('zd',0)->where('dj',0)->where('rl',1)->sum('amount');
        		    //自动冻结
        		    $zdd=Db::name('order')->whereDay('rltime', 'yesterday')->where('group_id',$groupid)->where('zd',0)->where('dj',1)->where('rl',1)->count();
        		    $zddj=Db::name('order')->whereDay('rltime', 'yesterday')->where('group_id',$groupid)->where('zd',0)->where('dj',1)->where('rl',1)->sum('amount');
        		    //手动正常
        		    $sdz=Db::name('order')->whereDay('rltime', 'yesterday')->where('group_id',$groupid)->where('zd',1)->where('dj',0)->where('rl',1)->count();
        		    $sdzj=Db::name('order')->whereDay('rltime', 'yesterday')->where('group_id',$groupid)->where('zd',1)->where('dj',0)->where('rl',1)->sum('amount');
        		    //手动冻结
        		    $sdd=Db::name('order')->whereDay('rltime', 'yesterday')->where('group_id',$groupid)->where('zd',1)->where('dj',1)->where('rl',1)->count();
        		    $sddj=Db::name('order')->whereDay('rltime', 'yesterday')->where('group_id',$groupid)->where('zd',1)->where('dj',1)->where('rl',1)->sum('amount');
        		    //查询所有用户
        		    $userdata=Db::name('user')->select();
        		    $usera='';
        		    if(!empty($userdata)&&$zdz>0){
        		         foreach ($userdata as $i) {
            		        $zcje=Db::name('order')->whereDay('rltime', 'yesterday')->where('group_id',$groupid)->where('tgid',$i['tguid'])->where('rl',1)->where('dj',0)->sum('amount');
            		        $djje=Db::name('order')->whereDay('rltime', 'yesterday')->where('group_id',$groupid)->where('tgid',$i['tguid'])->where('rl',1)->where('dj',1)->sum('amount');
            		        if($zcje!=0||$djje!=0){
            		             $usera=$usera.$i['tgname']." 正常:".$zcje." 冻结:".$djje."\n";
            		        }
            		    }
        		    }else{
        		        $usera='空';
        		    }
        		    //查询域名
        		    $seturl=Db::name('base_config')->where('name','domain')->find();
                    $hdurl=$seturl['data'].'/index/order/zr?groupid='.$groupid;
    		        $msg="本群".date('Y-m-d',strtotime('-1 day'))."的汇总\n🔱自动入账:\n正常: ".$zdzj." (".$zdz."笔)\n冻结: ".$zddj." (".$zdd."笔)\n\n🔆手动入账:\n正常: ".$sdzj." (".$sdz."笔)\n冻结: ".$sddj." (".$sdd."笔)\n\n🚻用户汇总🚻\n".$usera."\n";
    		        
                }elseif($msg=='我' || $msg=='账单'){
                    // 查询用户的账单汇总
                    // 日切逻辑
                    $now = time();
                    $cutoffTime = $this->getGroupCutoff($groupid);
                    $todayCutoff = strtotime(date('Y-m-d ' . $cutoffTime . ':00'));
                    
                    if ($now < $todayCutoff) {
                        $start = strtotime(date('Y-m-d ' . $cutoffTime . ':00', strtotime('-1 day')));
                        $end = $todayCutoff;
                    } else {
                        $start = $todayCutoff;
                        $end = strtotime(date('Y-m-d ' . $cutoffTime . ':00', strtotime('+1 day')));
                    }

                    // 获取汇率 (用于计算显示)
                    $rateConfig = Db::name('base_config')->where('name', 'rate')->find();
                    $baseRate = $rateConfig ? $rateConfig['data'] : 12.8;

                    // 查询该用户今日的所有有效订单
                    // 用户作为入款人(tgid匹配) 或者 下发收款人(reply to user)
                    // 入款: amount > 0, tgid = user_id
                    // 下发: amount < 0, tgid = user_id
                    
                    $orders = Db::name('order')
                        ->where('group_id', $groupid)
                        ->where('tgid', $user_id)
                        ->where('rltime', '>=', $start)
                        ->where('rltime', '<', $end)
                        ->where('amount', '<>', 0) // 排除开始标记
                        ->order('rltime', 'desc')
                        ->select();

                    $incomeCount = 0;
                    $incomeTotal = 0;
                    $incomeUsdtTotal = 0;
                    $incomeLines = [];

                    $outcomeTotal = 0;
                    $outcomeUsdtTotal = 0;

                    foreach ($orders as $v) {
                        $amount = floatval($v['amount']);
                        $usdt = isset($v['usdt']) && $v['usdt'] != 0 ? floatval($v['usdt']) : ($baseRate > 0 ? round(abs($amount) / $baseRate, 3) : 0);
                        
                        // 计算当时的汇率
                        $rate = ($usdt != 0) ? round(abs($amount) / abs($usdt), 2) : $baseRate;
                        $timeStr = date('H:i', $v['rltime']);

                        if ($amount > 0) {
                            $incomeCount++;
                            $incomeTotal += $amount;
                            $incomeUsdtTotal += $usdt;
                            // 格式: 15:30 1000/12.8 = 78.125u
                            $incomeLines[] = "{$timeStr} {$amount}/{$rate} = {$usdt}u";
                        } else {
                            $outcomeTotal += abs($amount);
                            $outcomeUsdtTotal += abs($usdt);
                        }
                    }

                    // 构建回复
                    $reply = "用户：@{$user_name}\n";
                    $reply .= "入款笔数：{$incomeCount}\n\n";
                    $reply .= "入款明细：\n";
                    
                    if (empty($incomeLines)) {
                        $reply .= "无\n";
                    } else {
                        // 如果超过5条，显示前5条
                        $showLines = array_slice($incomeLines, 0, 5);
                        $reply .= implode("\n", $showLines) . "\n";
                        if (count($incomeLines) > 5) {
                            $reply .= "...\n";
                        }
                    }
                    $reply .= "\n";
                    
                    $remainingUsdt = round($incomeUsdtTotal - $outcomeUsdtTotal, 2);
                    
                    $reply .= "入款总金额：{$incomeTotal} | {$incomeUsdtTotal} U\n";
                    $reply .= "下发总金额：{$outcomeTotal} | {$outcomeUsdtTotal} U\n";
                    $reply .= "未回合计：{$remainingUsdt} U";

                    // 只有超过5条时才显示跳转链接，或者始终显示方便查看？
                    // 需求: "如果超过5条则下方显示点击跳转完整账单"
                    $url = '';
                    $btnText = '';
                    if (count($incomeLines) > 5) {
                        $seturl = Db::name('base_config')->where('name','domain')->find();
                        // 这里可以跳转到个人账单页，目前暂时跳到完整账单页
                        $url = $seturl['data'] . '/index/order/jr?groupid=' . $groupid; // 理想情况应该能筛选用户，但目前jr页只按日期
                        $btnText = '点击跳转完整账单';
                        huiText($message_id, $groupid, $reply, $btnText, $url);
                    } else {
                        huiText($message_id, $groupid, $reply);
                    }
                    return 'true'; // Stop processing

    		    }elseif($msg=='meyes'){
    		    //表示查询我的的昨日汇总
    		    //自动正常
        		    $zdz=Db::name('order')->whereDay('rltime', 'yesterday')->where('group_id',$groupid)->where('tgid',$user_id)->where('zd',0)->where('dj',0)->where('rl',1)->count();
        		    $zdzj=Db::name('order')->whereDay('rltime', 'yesterday')->where('group_id',$groupid)->where('tgid',$user_id)->where('zd',0)->where('dj',0)->where('rl',1)->sum('amount');
        		    //自动冻结
        		    $zdd=Db::name('order')->whereDay('rltime', 'yesterday')->where('group_id',$groupid)->where('tgid',$user_id)->where('zd',0)->where('dj',1)->where('rl',1)->count();
        		    $zddj=Db::name('order')->whereDay('rltime', 'yesterday')->where('group_id',$groupid)->where('tgid',$user_id)->where('zd',0)->where('dj',1)->where('rl',1)->sum('amount');
        		    //手动正常
        		    $sdz=Db::name('order')->whereDay('rltime', 'yesterday')->where('group_id',$groupid)->where('tgid',$user_id)->where('zd',1)->where('dj',0)->where('rl',1)->count();
        		    $sdzj=Db::name('order')->whereDay('rltime', 'yesterday')->where('group_id',$groupid)->where('tgid',$user_id)->where('zd',1)->where('dj',0)->where('rl',1)->sum('amount');
        		    //手动冻结
        		    $sdd=Db::name('order')->whereDay('rltime', 'yesterday')->where('group_id',$groupid)->where('tgid',$user_id)->where('zd',1)->where('dj',1)->where('rl',1)->count();
        		    $sddj=Db::name('order')->whereDay('rltime', 'yesterday')->where('group_id',$groupid)->where('tgid',$user_id)->where('zd',1)->where('dj',1)->where('rl',1)->sum('amount');
    		        $msg="我".date('Y-m-d',strtotime('-1 day'))."的汇总\n\n🔱自动入账:\n正常: ".$zdzj." (".$zdz."笔)\n冻结: ".$zddj." (".$zdd."笔)\n\n🔆手动入账:\n正常: ".$sdzj." (".$sdz."笔)\n冻结: ".$sddj." (".$sdd."笔)\n";
    		    }else{
    		        $name = empty($match[1][0])?'':$match[1][0];//指令
    		        //发送/姓名金额 例如 /李四100 查询李四100元订单
    		        $num = empty($match[2][0])?'':$match[2][0];//金额
    		        //判断是查单还是入单
    		             //判断是否有这笔订单
        		        $order=Db::name('order')->where('accname',$name)->where('amount',$num)->where('rl',0)->order('id desc')->find();
        		        if(empty($order)){
        		            $msg="\n❗️ 暂时未查到明细/或已被认领,请30秒后重新发送.";
        		        }else{
        		            if($order['dj']!=1){
        		               //绑定信息
            		            $dataaa = ['group_id' =>$groupid, 'group_name' => $grouptitle, 'tgid' => $user_id, 'tgname' => $user_name, 'rl' => 1, 'rltime' => time()];
            		            $r=DB::name('order')->where('id',$order['id'])->update($dataaa);
            		            if($r){
            		                $msg="\n ✅ ️".$name.' '.$num." ( ".date('Y-m-d  H:i:s')." )  ";
            		            }else{
            		                $msg="\n❗️认领失败！.";
            		            } 
        		            }else{
        		                $dataaa = ['group_id' =>$groupid, 'group_name' => $grouptitle, 'tgid' => $user_id, 'tgname' => $user_name, 'rl' => 1, 'rltime' => time()];
            		            $r=DB::name('order')->where('id',$order['id'])->update($dataaa);
            		            if($r){
            		                $msg="\n⚠该资金已冻结 ".$name. " ".$num." ( ".date('Y-m-d  H:i:s')." ) ";
            		            }else{
            		                $msg="\n❗️认领失败！.";
            		            } 
        		            }
        		            
        		        }
    		       
    		    }
    		    if(!empty($hdurl)){
    		        huiText($message_id,$groupid,$msg,'点击跳转完整账单',$hdurl);
    		    }else{
    		        huiText($message_id,$groupid,$msg);  
    		    }
    		   
    		}
	    }
    }
    // 显示账单
    private function sendBill($message_id, $groupid) {
        // 日切逻辑
        $now = time();
        $cutoffTime = $this->getGroupCutoff($groupid);
        $todayCutoff = strtotime(date('Y-m-d ' . $cutoffTime . ':00'));
        
        if ($now < $todayCutoff) {
            $businessDayStart = strtotime(date('Y-m-d ' . $cutoffTime . ':00', strtotime('-1 day')));
            $businessDayEnd = $todayCutoff;
        } else {
            $businessDayStart = $todayCutoff;
            $businessDayEnd = strtotime(date('Y-m-d ' . $cutoffTime . ':00', strtotime('+1 day')));
        }

        // 获取汇率
        $rateConfig = Db::name('base_config')->where('name', 'rate')->find();
        $baseRate = $rateConfig ? $rateConfig['data'] : 12.8;

        // 统计时间范围使用业务周期
        $todayStart = $businessDayStart;
        $todayEnd = $businessDayEnd;
        
        // Fetch all orders for details
        $orders = Db::name('order')
            ->where('group_id', $groupid)
            ->where('rltime', '>=', $todayStart)
            ->where('rltime', '<', $todayEnd)
            ->select();

        // Initialize totals and lists
        $incomeCount = 0;
        $incomeTotal = 0;
        $incomeTotalUSDT = 0;
        $incomeLines = [];

        $outcomeCount = 0;
        $outcomeTotal = 0; // RMB absolute
        $outcomeTotalUSDT = 0; // USDT absolute
        $outcomeLines = [];

        foreach ($orders as $order) {
            if ($order['zd'] == 2) continue; // Skip start marker

            $oAmount = $order['amount'];
            $oUsdt = isset($order['usdt']) ? $order['usdt'] : 0;
            
            // Fallback calculation if usdt column is empty (for old records)
            if ($oUsdt == 0 && $oAmount != 0 && $baseRate > 0) {
                 $oUsdt = round($oAmount / $baseRate, 3);
            }
            
            $oRate = ($oUsdt != 0) ? round(abs($oAmount) / abs($oUsdt), 2) : 0;
            $oTimeStr = date('m-d H:i', $order['rltime']);

            if ($oAmount > 0) {
                // Income
                $incomeCount++;
                $incomeTotal += $oAmount;
                $incomeTotalUSDT += $oUsdt;
                $incomeLines[] = "{$oTimeStr} {$oAmount}/{$oRate} = {$oUsdt}u";
            } elseif ($oAmount < 0) {
                // Outcome
                $outcomeCount++;
                $outcomeTotal += abs($oAmount);
                $outcomeTotalUSDT += abs($oUsdt);
                $outcomeLines[] = "{$oTimeStr} " . abs($oUsdt) . "u (" . abs($oAmount) . ")";
            }
        }
        
        // Get latest 6 lines
        $incomeListStr = implode("\n", array_slice($incomeLines, -6));
        $outcomeListStr = implode("\n", array_slice($outcomeLines, -6));
        
        // 合计未回 (总入USDT - 总出USDT)
        $balanceUSDT = round($incomeTotalUSDT - $outcomeTotalUSDT, 2);

        // 构建回复消息
        $replyMsg = "总入 ({$incomeCount})\n";
        $replyMsg .= $incomeListStr . "\n\n";
        
        $replyMsg .= "总出 ({$outcomeCount})\n";
        $replyMsg .= $outcomeListStr . "\n\n";

        $replyMsg .= "入账汇率: {$baseRate}\n";
        $replyMsg .= "入账总数: {$incomeTotal}\n";
        $replyMsg .= "入账合计: {$incomeTotal} | {$incomeTotalUSDT}U\n\n";
        
        $replyMsg .= "下发总数: {$outcomeCount}\n";
        $replyMsg .= "下发合计: {$outcomeTotal} | {$outcomeTotalUSDT}U\n\n";
        
        $replyMsg .= "合计未回: {$balanceUSDT} U";
        
        // 查询域名用于跳转
        $seturl = Db::name('base_config')->where('name','domain')->find();
        $hdurl = $seturl['data'] . '/index/order/jr?groupid=' . $groupid;

        huiText($message_id, $groupid, $replyMsg, '点击跳转完整账单', $hdurl);
    }

    //上下分操作
    function groupgl($message_id,$groupid,$grouptitle,$msgtype,$msg,$xin,$user_id,$user_name,$toid,$toname){
        if($msgtype=='text'){
            $zl=substr($msg, 0, 1 );
            $is_xiafa = (strpos($msg, '下发') === 0);
            
    		if($zl=='+' || $zl == '-' || $is_xiafa){
    		    // 日切逻辑
                $now = time();
                $cutoffTime = $this->getGroupCutoff($groupid);
                $todayCutoff = strtotime(date('Y-m-d ' . $cutoffTime . ':00'));
                
                if ($now < $todayCutoff) {
                    $businessDayStart = strtotime(date('Y-m-d ' . $cutoffTime . ':00', strtotime('-1 day')));
                    $businessDayEnd = $todayCutoff;
                } else {
                    $businessDayStart = $todayCutoff;
                    $businessDayEnd = strtotime(date('Y-m-d ' . $cutoffTime . ':00', strtotime('+1 day')));
                }

                // 检查是否已开启记账 (查找本业务周期内的开始标记)
                $hasStarted = Db::name('order')
                    ->where('group_id', $groupid)
                    ->where('zd', 2)
                    ->where('rltime', '>=', $businessDayStart)
                    ->where('rltime', '<', $businessDayEnd)
                    ->find();

                if (!$hasStarted) {
                    $msg = "❗ 请管理员发送 '开始' 开启今日记账";
                    huiText($message_id, $groupid, $msg);
                    return;
                }

                // 获取汇率，如果没配置则默认为12.8
                $rateConfig = Db::name('base_config')->where('name', 'rate')->find();
                $baseRate = $rateConfig ? $rateConfig['data'] : 12.8;
                $usedRate = $baseRate;

    		    // 解析金额和汇率
    		    if ($is_xiafa) {
    		        $msgVal = trim(str_replace('下发', '', $msg));
    		    } else {
    		        $msgVal = trim(substr($msg, 1));
    		    }

                $isUSDT = false;
                $calculatedUsdt = 0; // Initialize calculatedUsdt
                
                // 格式1: -金额U (例如 -100U)
                if (preg_match('/^(\d+(\.\d+)?)u$/i', $msgVal, $match)) {
                    $uAmount = $match[1];
                    $amount = $uAmount * $usedRate; // 存为RMB
                    $isUSDT = true;
                    $calculatedUsdt = $uAmount;
                } 
                // 格式2: -金额/汇率 (例如 -100/7.0)
                elseif (strpos($msgVal, '/') !== false) {
                    $parts = explode('/', $msgVal);
                    if (count($parts) == 2 && is_numeric(trim($parts[0])) && is_numeric(trim($parts[1]))) {
                        $val = trim($parts[0]);
                        $overrideRate = trim($parts[1]);
                        $amount = $val; // 这里存的是RMB
                        $usedRate = $overrideRate;
                        $calculatedUsdt = $usedRate > 0 ? round($amount / $usedRate, 3) : 0;
                    } else {
                         // 包含/但格式不对，当做普通金额处理（可能是日期或其他）
                         // 或者尝试 regex 匹配
                         if (preg_match('/^(\d+(\.\d+)?)\s*\/\s*(\d+(\.\d+)?)$/', $msgVal, $match)) {
                            $val = $match[1];
                            $overrideRate = $match[3];
                            $amount = $val;
                            $usedRate = $overrideRate;
                            $calculatedUsdt = $usedRate > 0 ? round($amount / $usedRate, 3) : 0;
                         } else {
                            $amount = floatval($msgVal); // 默认为RMB
                            $calculatedUsdt = $usedRate > 0 ? round($amount / $usedRate, 3) : 0;
                         }
                    }
                }
                // 格式3: -金额 (例如 -100)
                else {
                    $amount = $msgVal; // 默认为RMB
                    $calculatedUsdt = $usedRate > 0 ? round($amount / $usedRate, 3) : 0;
                }

                // 确定正负
                // 如果是下发 或者 符号是-，都是支出
                $is_outcome = ($zl == '-' || $is_xiafa);
                $finalAmount = ($is_outcome) ? -1 * abs($amount) : abs($amount);
                $finalUsdt = ($is_outcome) ? -1 * abs($calculatedUsdt) : abs($calculatedUsdt);

    		    $orderdata = [
    		        'amount' => $finalAmount, 
    		        'zd' => 1, 
    		        'group_id' => $groupid, 
    		        'rl' => 1, 
    		        'tgid' => $toid, 
    		        'tgname' => $toname, 
    		        'group_name' => $grouptitle, 
    		        'rltime' => time(),
    		        'usdt' => $finalUsdt,
    		        'operator_name' => $user_name // 记录操作人
    		    ];
                try {
                Db::name('order')->insert($orderdata);
                } catch (\Throwable $e) {
                    // 如果插入失败 (可能是缺少字段)，尝试移除新字段后重试
                    unset($orderdata['usdt']);
                    unset($orderdata['operator_name']);
                    try {
                        Db::name('order')->insert($orderdata);
                        // 记录错误但不中断
                        Log::error("Order insert fallback used. Missing columns? Error: " . $e->getMessage());
                    } catch (\Throwable $e2) {
                        Log::error("Order insert failed completely: " . $e2->getMessage());
                        huiText($message_id, $groupid, "❗ 系统错误：无法写入账单，请联系管理员检查数据库。");
                        return;
                    }
                }
                
                $this->sendBill($message_id, $groupid);
    		}
        }
        
    }
    //私聊
    function ydy($id,$msg){
        sendText($id,$msg);
    }
}