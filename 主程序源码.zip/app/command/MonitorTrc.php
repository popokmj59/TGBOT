<?php
declare (strict_types = 1);

namespace app\command;

use think\console\Command;
use think\console\Input;
use think\console\Output;
use think\facade\Db;
use think\facade\Log;

class MonitorTrc extends Command
{
    protected function configure()
    {
        // 指令配置
        $this->setName('monitor:trc')
            ->setDescription('Monitor TRC20 Address Transactions');
    }

    protected function execute(Input $input, Output $output)
    {
        $output->writeln("Starting TRC20 Address Monitor...");
        
        // USDT Contract
        $usdtContract = "TR7NHqjeKQxGTCi8q8ZY4pL8otSzgjLj6t";
        
        while (true) {
            try {
                // Get all monitored addresses
                $monitors = Db::name('address_monitor')->select();
                
                if ($monitors->isEmpty()) {
                    $output->writeln("No addresses to monitor. Sleeping...");
                    sleep(10);
                    continue;
                }

                foreach ($monitors as $monitor) {
                    $address = $monitor['address'];
                    $lastTs = $monitor['last_tx_timestamp'];
                    $tgId = $monitor['tg_id'];
                    
                    $output->writeln("Checking {$address}...");

                    // Fetch latest USDT transfers
                    // Limit 10 to cover recent potential txs
                    $url = "https://apilist.tronscan.org/api/token_trc20/transfers?limit=10&start=0&sort=-timestamp&count=true&relatedAddress={$address}&contract_address={$usdtContract}";
                    
                    $res = $this->get_http($url);
                    
                    if (isset($res['token_transfers']) && !empty($res['token_transfers'])) {
                        $newMaxTs = $lastTs;
                        $notifications = [];

                        // Iterate in reverse (oldest first) if we want to notify in order, 
                        // but API returns newest first.
                        // We filter for > lastTs
                        
                        $newTxs = [];
                        foreach ($res['token_transfers'] as $tx) {
                            $ts = isset($tx['block_ts']) ? $tx['block_ts'] : 0;
                            if ($ts > $lastTs) {
                                $newTxs[] = $tx;
                                if ($ts > $newMaxTs) {
                                    $newMaxTs = $ts;
                                }
                            }
                        }
                        
                        // Process new transactions (reverse to send oldest first)
                        $newTxs = array_reverse($newTxs);
                        
                        foreach ($newTxs as $tx) {
                            $amountRaw = isset($tx['quant']) ? $tx['quant'] : 0;
                            $decimals = isset($tx['tokenInfo']['tokenDecimal']) ? $tx['tokenInfo']['tokenDecimal'] : 6;
                            $amount = $amountRaw / pow(10, $decimals);
                            $amountStr = number_format($amount, 2);
                            
                            $ts = isset($tx['block_ts']) ? $tx['block_ts'] : 0;
                            $time = date('Y-m-d H:i:s', $ts / 1000);
                            
                            $from = isset($tx['from_address']) ? $tx['from_address'] : '';
                            $to = isset($tx['to_address']) ? $tx['to_address'] : '';
                            $txHash = isset($tx['transaction_id']) ? $tx['transaction_id'] : '';
                            $status = (isset($tx['finalResult']) && $tx['finalResult'] == 'SUCCESS') ? '✅' : '❌';
                            
                            if ($to == $address) {
                                $type = "收入";
                                $symbol = "+";
                                $otherAddr = $from;
                            } else {
                                $type = "支出";
                                $symbol = "-";
                                $otherAddr = $to;
                            }
                            
                            $shortAddr = substr($otherAddr, 0, 4) . '...' . substr($otherAddr, -4);
                            $shortHash = substr($txHash, 0, 6) . '...' . substr($txHash, -6);
                            
                            $msg = "🔔 <b>USDT 变动通知</b>\n\n";
                            $msg .= "监控地址: <code>{$address}</code>\n";
                            $msg .= "类型: <b>{$type}</b>\n";
                            $msg .= "金额: <b>{$symbol}{$amountStr} USDT</b>\n";
                            $msg .= "对方: <code>{$otherAddr}</code>\n";
                            $msg .= "时间: {$time}\n";
                            $msg .= "状态: {$status}\n";
                            $msg .= "哈希: <a href='https://tronscan.org/#/transaction/{$txHash}'>{$shortHash}</a>";
                            
                            $this->sendText($tgId, $msg);
                        }

                        // Update DB if we found newer transactions
                        if ($newMaxTs > $lastTs) {
                            Db::name('address_monitor')
                                ->where('id', $monitor['id'])
                                ->update(['last_tx_timestamp' => $newMaxTs]);
                        }
                    }
                    
                    // Sleep to avoid rate limiting
                    sleep(2); 
                }
                
                // Sleep between cycles
                sleep(5); 

            } catch (\Throwable $e) {
                $output->writeln("Error: " . $e->getMessage());
                Log::error("MonitorTrc Error: " . $e->getMessage());
                sleep(10);
            }
        }
    }

    private function get_http($url) {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
            "Accept: application/json"
        ]);
        $output = curl_exec($ch);
        curl_close($ch);
        return json_decode($output, true);
    }

    private function sendText($chat_id, $text) {
        try {
            $tokenRow = Db::name('robotconfig')->where('name', 'token')->find();
            if (!$tokenRow) return;
            $token = $tokenRow['data'];
            
            $url = "https://api.telegram.org/bot{$token}/sendMessage?chat_id={$chat_id}&text=" . urlencode($text) . "&parse_mode=HTML";
            $this->get_http($url);
        } catch (\Exception $e) {
            // ignore
        }
    }
}

