<?php
namespace app\command;

use think\console\Command;
use think\console\Input;
use think\console\Output;
use think\facade\Db;
use think\facade\Cache;
use app\index\controller\Tg;

class TgQueueConsumer extends Command
{
    protected function configure()
    {
        // 指令配置
        $this->setName('tg:consume')
            ->setDescription('Telegram Message Queue Consumer');
    }

    protected function execute(Input $input, Output $output)
    {
        $output->writeln("Starting Telegram Message Consumer...");
        
        // 实例化 Tg 控制器，以便调用其中的方法
        // 注意：Tg控制器中的方法大多是 public 的，可以直接调用
        // 但需要注意 request() 对象的模拟，因为 CLI 模式下没有 HTTP 请求
        // 实际上，我们最好把 Tg::message() 中的逻辑拆分，或者我们模拟 request 参数
        
        // 由于 Tg::message() 强依赖 request()->param()，我们需要在调用前设置 request
        // 但 TP6 的 request 是单例的，比较难在 CLI 中完美模拟多次请求
        
        // 更好的策略是：
        // 把 Tg 类中的核心逻辑剥离出来，或者我们在 CLI 中重写一部分调度逻辑
        // 鉴于目前代码都在 Tg.php 中，且依赖 $this->checkAuth 等私有方法
        // 我们尝试实例化 Tg 类，并用反射或直接修改代码来适应。
        
        // 这里的策略是：
        // 消费者循环读取 Redis 队列
        // 每次读取到消息，我们构造一个假的 Request 对象或者直接传递参数给一个新的处理方法
        // 为了最小化改动，我们将在 Tg.php 中新增一个 public function processMessage($params)
        // 然后把原来的 message() 内容搬过去，message() 只负责接收并入队
        
        $redis = Cache::store('redis')->handler();
        $queueName = 'tg_message_queue';
        
        $tgController = new Tg();

        while (true) {
            try {
                // 阻塞式弹出，超时时间 5 秒
                $dataJson = $redis->blPop([$queueName], 5);
                
                if ($dataJson) {
                    // blPop 返回数组 [key, value]
                    $payload = json_decode($dataJson[1], true);
                    
                    if ($payload) {
                        $output->writeln("Processing message: " . ($payload['message']['message_id'] ?? 'unknown'));
                        
                        // 调用 Tg 控制器的新方法处理消息
                        // 我们需要在 Tg.php 中新增 processMessageFromArray 方法
                        $tgController->processMessageFromArray($payload);
                    }
                }
                
                // 防止内存泄漏，定期清理数据库连接等（TP6通常会自动处理，但长驻进程需注意）
                // Db::close(); // 如果需要
                
            } catch (\Throwable $e) {
                $output->writeln("Error: " . $e->getMessage());
                // 防止死循环刷屏
                sleep(1);
            }
        }
    }
}

